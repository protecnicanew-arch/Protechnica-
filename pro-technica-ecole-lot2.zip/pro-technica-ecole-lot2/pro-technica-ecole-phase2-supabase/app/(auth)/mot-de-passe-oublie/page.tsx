"use client";

import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import Link from "next/link";
import { GraduationCap, Mail, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { requestPasswordReset } from "@/lib/auth/auth-service";

const schema = z.object({ email: z.string().email("Adresse email invalide") });
type FormValues = z.infer<typeof schema>;

export default function ForgotPasswordPage() {
  const [sent, setSent] = useState(false);
  const [serverError, setServerError] = useState<string | null>(null);
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<FormValues>({ resolver: zodResolver(schema) });

  const onSubmit = async (data: FormValues) => {
    setServerError(null);
    const result = await requestPasswordReset(data.email);
    if (!result.success) {
      setServerError(result.error ?? "Une erreur est survenue.");
      return;
    }
    setSent(true);
  };

  return (
    <div className="min-h-screen grid lg:grid-cols-2">
      <div className="hidden lg:flex flex-col justify-between premium-gradient p-10 text-white">
        <div className="flex items-center gap-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary">
            <GraduationCap className="h-5 w-5" />
          </div>
          <span className="font-semibold">PRO TECHNICA ÉCOLE</span>
        </div>
        <div>
          <h2 className="text-3xl font-semibold leading-tight mb-3">
            Mot de passe oublié ?<br />Pas de panique.
          </h2>
          <p className="text-white/60 max-w-md">
            Indiquez votre email professionnel et nous vous enverrons un lien sécurisé pour le réinitialiser.
          </p>
        </div>
        <p className="text-xs text-white/40">© 2026 PRO TECHNICA ÉCOLE</p>
      </div>

      <div className="flex items-center justify-center p-6">
        <div className="w-full max-w-sm">
          <div className="lg:hidden flex items-center gap-2 mb-8">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary">
              <GraduationCap className="h-5 w-5 text-white" />
            </div>
            <span className="font-semibold">PRO TECHNICA ÉCOLE</span>
          </div>

          <Link href="/login" className="inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground mb-6">
            <ArrowLeft className="h-3.5 w-3.5" /> Retour à la connexion
          </Link>

          <h1 className="text-2xl font-semibold mb-1">Mot de passe oublié</h1>
          <p className="text-sm text-muted-foreground mb-6">
            Nous vous enverrons un lien de réinitialisation par email.
          </p>

          {sent ? (
            <div className="rounded-lg border border-green-200 bg-green-50 px-4 py-3 text-sm text-green-800">
              Si un compte existe avec cette adresse, un email vient de vous être envoyé.
              Vérifiez votre boîte de réception (et vos spams).
            </div>
          ) : (
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
              <div>
                <label className="text-sm font-medium mb-1.5 block">Email</label>
                <div className="flex items-center gap-2 rounded-lg border border-border bg-background px-3 py-2.5 focus-within:ring-2 focus-within:ring-ring">
                  <Mail className="h-4 w-4 text-muted-foreground" />
                  <input
                    type="email"
                    placeholder="vous@protechnica.sn"
                    className="w-full bg-transparent text-sm outline-none"
                    {...register("email")}
                  />
                </div>
                {errors.email && <p className="text-xs text-red-600 mt-1">{errors.email.message}</p>}
              </div>

              {serverError && (
                <p className="text-sm text-red-600 bg-red-50 border border-red-200 rounded-lg px-3 py-2">
                  {serverError}
                </p>
              )}

              <Button type="submit" className="w-full" size="lg" disabled={isSubmitting}>
                {isSubmitting ? "Envoi…" : "Envoyer le lien"}
              </Button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
