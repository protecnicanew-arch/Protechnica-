"use client";

import { useEffect, useState } from "react";
import { Search, History } from "lucide-react";
import { DashboardShell } from "@/components/layout/DashboardShell";
import { getRecentActivity } from "@/lib/services/dashboard.service";
import { useSession } from "@/lib/auth/use-session";
import { can } from "@/lib/auth/permissions";
import type { ActivityLogEntry } from "@/lib/types";
import { formatDate } from "@/lib/utils";

export default function AuditPage() {
  const { profile, loading: sessionLoading } = useSession();
  const [entries, setEntries] = useState<ActivityLogEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");

  useEffect(() => {
    getRecentActivity(200).then((rows) => {
      setEntries(rows);
      setLoading(false);
    });
  }, []);

  const canView = profile ? can(profile.role, "audit", "voir") : false;
  const filtered = entries.filter(
    (e) => search.trim() === "" || e.userName.toLowerCase().includes(search.toLowerCase()) || e.action.toLowerCase().includes(search.toLowerCase())
  );

  if (sessionLoading) {
    return <DashboardShell title="Journal d'audit"><p className="text-sm text-muted-foreground">Chargement…</p></DashboardShell>;
  }

  if (!canView) {
    return (
      <DashboardShell title="Journal d'audit">
        <p className="text-sm text-muted-foreground">Réservé aux comptes Administration et Direction.</p>
      </DashboardShell>
    );
  }

  return (
    <DashboardShell title="Journal d'audit">
      <p className="text-sm text-muted-foreground mb-5">
        Actions sensibles enregistrées automatiquement (créations, modifications, suppressions) — 200 dernières entrées.
      </p>

      <div className="flex items-center gap-2 rounded-lg border border-border bg-background px-3 py-2 mb-5 max-w-md">
        <Search className="h-4 w-4 text-muted-foreground shrink-0" />
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Rechercher par utilisateur ou action…"
          className="w-full bg-transparent text-sm outline-none placeholder:text-muted-foreground"
        />
      </div>

      <div className="rounded-xl border border-border bg-card divide-y divide-border">
        {filtered.map((e) => (
          <div key={e.id} className="flex items-center justify-between px-4 py-3 text-sm">
            <div className="flex items-center gap-2.5 min-w-0">
              <History className="h-4 w-4 text-muted-foreground shrink-0" />
              <div className="min-w-0">
                <p className="font-medium truncate">{e.userName}</p>
                <p className="text-xs text-muted-foreground truncate">{e.action}</p>
              </div>
            </div>
            <span className="text-xs text-muted-foreground shrink-0 ml-3">{formatDate(e.date)}</span>
          </div>
        ))}
        {!loading && filtered.length === 0 && (
          <p className="text-center py-8 text-sm text-muted-foreground">Aucune entrée trouvée.</p>
        )}
      </div>
    </DashboardShell>
  );
}
