"use client";

import { useRouter } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import { DashboardShell } from "@/components/layout/DashboardShell";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { StudentFormDialog } from "@/components/students/StudentFormDialog";
import { createStudentAccount } from "@/lib/services/admin-users.service";
import { useAcademicStore } from "@/lib/store";

export default function NouvelEtudiantPage() {
  const router = useRouter();
  const { classes, filieres } = useAcademicStore();

  return (
    <DashboardShell title="Nouvel étudiant">
      <Button variant="ghost" size="sm" className="gap-1.5 mb-4 -ml-2" onClick={() => router.push("/dashboard/etudiants")}>
        <ArrowLeft className="h-4 w-4" /> Retour aux étudiants
      </Button>

      <Card>
        <CardContent className="pt-6">
          {classes.length === 0 || filieres.length === 0 ? (
            <p className="text-sm text-muted-foreground">
              Créez d'abord au moins une filière et une classe avant d'inscrire un étudiant.
            </p>
          ) : (
            <StudentFormDialog
              classes={classes}
              filieres={filieres}
              onSubmit={async (data) => {
                await createStudentAccount(data);
                router.push("/dashboard/etudiants");
              }}
            />
          )}
        </CardContent>
      </Card>
    </DashboardShell>
  );
}
