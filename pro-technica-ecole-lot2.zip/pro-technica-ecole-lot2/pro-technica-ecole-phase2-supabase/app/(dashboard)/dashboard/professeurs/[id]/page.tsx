"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { ArrowLeft, Mail, Phone, Calendar, Clock } from "lucide-react";
import { DashboardShell } from "@/components/layout/DashboardShell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  getTeacherById, getScheduleByTeacher, getClasses, getActivityLog,
} from "@/lib/data";
import type { Teacher, ScheduleSlot, Classe, ActivityLogEntry } from "@/lib/types";
import { formatDate } from "@/lib/utils";

type Tab = "infos" | "emploi" | "historique";
const JOURS: ScheduleSlot["jour"][] = ["Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"];

export default function ProfesseurProfilPage() {
  const params = useParams<{ id: string }>();
  const router = useRouter();
  const [teacher, setTeacher] = useState<Teacher | null | undefined>(undefined);
  const [schedule, setSchedule] = useState<ScheduleSlot[]>([]);
  const [classes, setClasses] = useState<Classe[]>([]);
  const [activity, setActivity] = useState<ActivityLogEntry[]>([]);
  const [tab, setTab] = useState<Tab>("infos");

  useEffect(() => {
    getTeacherById(params.id).then(setTeacher);
    getScheduleByTeacher(params.id).then(setSchedule);
    getClasses().then(setClasses);
    getActivityLog().then(setActivity);
  }, [params.id]);

  if (teacher === undefined) {
    return (
      <DashboardShell title="Professeur">
        <p className="text-sm text-muted-foreground">Chargement…</p>
      </DashboardShell>
    );
  }

  if (teacher === null) {
    return (
      <DashboardShell title="Professeur introuvable">
        <p className="text-sm text-muted-foreground mb-4">Ce professeur n'existe pas ou a été supprimé.</p>
        <Button variant="outline" onClick={() => router.push("/dashboard/professeurs")} className="gap-1.5">
          <ArrowLeft className="h-4 w-4" /> Retour à la liste
        </Button>
      </DashboardShell>
    );
  }

  const classeName = (id: string) => classes.find((c) => c.id === id)?.nom ?? "—";
  const teacherActivity = activity.filter((a) => a.userName === teacher.fullName);

  const tabs: { id: Tab; label: string }[] = [
    { id: "infos", label: "Informations" },
    { id: "emploi", label: "Emploi du temps" },
    { id: "historique", label: "Historique" },
  ];

  return (
    <DashboardShell title="Fiche professeur">
      <Button variant="ghost" size="sm" className="gap-1.5 mb-4 -ml-2" onClick={() => router.push("/dashboard/professeurs")}>
        <ArrowLeft className="h-4 w-4" /> Retour aux professeurs
      </Button>

      <Card className="mb-6">
        <CardContent className="pt-6 flex flex-col sm:flex-row sm:items-center gap-4">
          <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center text-xl font-semibold text-primary shrink-0">
            {teacher.fullName.split(" ").map((n) => n[0]).join("").slice(0, 2)}
          </div>
          <div className="flex-1">
            <h2 className="text-lg font-semibold">{teacher.fullName}</h2>
            <div className="flex flex-wrap gap-1.5 mt-1.5 mb-2">
              {teacher.matieres.map((m) => (
                <Badge key={m} variant="outline">{m}</Badge>
              ))}
            </div>
            <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted-foreground">
              <span className="flex items-center gap-1"><Mail className="h-3.5 w-3.5" /> {teacher.email}</span>
              <span className="flex items-center gap-1"><Phone className="h-3.5 w-3.5" /> {teacher.phone}</span>
              <span className="flex items-center gap-1"><Calendar className="h-3.5 w-3.5" /> Embauché le {formatDate(teacher.dateEmbauche)}</span>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="flex gap-1 border-b border-border mb-5 overflow-x-auto">
        {tabs.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`px-4 py-2.5 text-sm font-medium whitespace-nowrap border-b-2 -mb-px transition-colors ${
              tab === t.id ? "border-primary text-primary" : "border-transparent text-muted-foreground hover:text-foreground"
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {tab === "infos" && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Card>
            <CardHeader><CardTitle>Matières enseignées</CardTitle></CardHeader>
            <CardContent className="flex flex-wrap gap-2">
              {teacher.matieres.map((m) => <Badge key={m}>{m}</Badge>)}
            </CardContent>
          </Card>
          <Card>
            <CardHeader><CardTitle>Classes affectées</CardTitle></CardHeader>
            <CardContent className="space-y-1.5 text-sm">
              {teacher.classesIds.map((id) => (
                <p key={id} className="font-medium">{classeName(id)}</p>
              ))}
              {teacher.classesIds.length === 0 && (
                <p className="text-muted-foreground">Aucune classe affectée.</p>
              )}
            </CardContent>
          </Card>
        </div>
      )}

      {tab === "emploi" && (
        <Card>
          <CardHeader><CardTitle>Emploi du temps hebdomadaire</CardTitle></CardHeader>
          <CardContent>
            {schedule.length === 0 ? (
              <p className="text-sm text-muted-foreground">Aucun créneau planifié.</p>
            ) : (
              <div className="space-y-2">
                {JOURS.filter((j) => schedule.some((s) => s.jour === j)).map((jour) => (
                  <div key={jour}>
                    <p className="text-xs font-semibold uppercase text-muted-foreground tracking-wide mt-3 mb-1.5">{jour}</p>
                    {schedule.filter((s) => s.jour === jour).map((s) => (
                      <div key={s.id} className="flex items-center justify-between rounded-lg border border-border px-4 py-3 text-sm mb-1.5">
                        <div>
                          <p className="font-medium">{s.matiere} — {classeName(s.classeId)}</p>
                          {s.salle && <p className="text-xs text-muted-foreground">Salle {s.salle}</p>}
                        </div>
                        <span className="flex items-center gap-1.5 text-xs text-muted-foreground shrink-0">
                          <Clock className="h-3.5 w-3.5" /> {s.heureDebut} – {s.heureFin}
                        </span>
                      </div>
                    ))}
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {tab === "historique" && (
        <Card>
          <CardHeader><CardTitle>Activité récente</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            {teacherActivity.length === 0 ? (
              <p className="text-sm text-muted-foreground">Aucune activité enregistrée pour ce professeur.</p>
            ) : (
              teacherActivity.map((a) => (
                <div key={a.id} className="text-sm">
                  <p className="text-muted-foreground">{a.action}</p>
                  <p className="text-xs text-muted-foreground">{formatDate(a.date)}</p>
                </div>
              ))
            )}
          </CardContent>
        </Card>
      )}
    </DashboardShell>
  );
}
