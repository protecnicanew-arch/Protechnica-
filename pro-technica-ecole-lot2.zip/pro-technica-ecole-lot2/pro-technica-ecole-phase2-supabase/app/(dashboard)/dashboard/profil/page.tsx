"use client";

import { useEffect, useState } from "react";
import { DashboardShell } from "@/components/layout/DashboardShell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { createClient } from "@/lib/supabase/client";
import { useSession } from "@/lib/auth/use-session";
import { updatePassword } from "@/lib/auth/auth-service";
import { ROLE_LABELS } from "@/lib/auth/permissions";

export default function ProfilPage() {
  const { profile, loading } = useSession();
  const [phone, setPhone] = useState("");
  const [savingInfo, setSavingInfo] = useState(false);
  const [infoSaved, setInfoSaved] = useState(false);

  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [pwdError, setPwdError] = useState<string | null>(null);
  const [pwdSaved, setPwdSaved] = useState(false);
  const [savingPwd, setSavingPwd] = useState(false);

  useEffect(() => {
    if (profile) setPhone(profile.phone ?? "");
  }, [profile]);

  const saveInfo = async () => {
    if (!profile) return;
    setSavingInfo(true);
    const supabase = createClient();
    await supabase.from("profiles").update({ phone }).eq("id", profile.id);
    setSavingInfo(false);
    setInfoSaved(true);
    setTimeout(() => setInfoSaved(false), 2500);
  };

  const changePassword = async () => {
    setPwdError(null);
    if (newPassword.length < 6) {
      setPwdError("Le mot de passe doit contenir au moins 6 caractères.");
      return;
    }
    if (newPassword !== confirmPassword) {
      setPwdError("Les deux mots de passe ne correspondent pas.");
      return;
    }
    setSavingPwd(true);
    const result = await updatePassword(newPassword);
    setSavingPwd(false);
    if (!result.success) {
      setPwdError(result.error ?? "Échec de la mise à jour.");
      return;
    }
    setNewPassword("");
    setConfirmPassword("");
    setPwdSaved(true);
    setTimeout(() => setPwdSaved(false), 2500);
  };

  if (loading || !profile) {
    return (
      <DashboardShell title="Mon profil">
        <p className="text-sm text-muted-foreground">Chargement…</p>
      </DashboardShell>
    );
  }

  return (
    <DashboardShell title="Mon profil">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-3xl">
        <Card>
          <CardContent className="pt-6 flex items-center gap-4">
            <div className="h-14 w-14 rounded-full bg-primary/10 flex items-center justify-center text-lg font-semibold text-primary shrink-0">
              {profile.full_name.split(" ").map((n) => n[0]).join("").slice(0, 2)}
            </div>
            <div>
              <p className="font-semibold">{profile.full_name}</p>
              <p className="text-xs text-muted-foreground">{profile.email}</p>
              <p className="text-xs text-primary mt-0.5">{ROLE_LABELS[profile.role]}</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>Coordonnées</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            <div>
              <label className="text-sm font-medium mb-1.5 block">Téléphone</label>
              <input className="input" value={phone} onChange={(e) => setPhone(e.target.value)} />
            </div>
            <div className="flex items-center gap-3">
              <Button size="sm" onClick={saveInfo} disabled={savingInfo}>{savingInfo ? "…" : "Enregistrer"}</Button>
              {infoSaved && <span className="text-xs text-emerald-600">Enregistré ✓</span>}
            </div>
          </CardContent>
        </Card>

        <Card className="sm:col-span-2">
          <CardHeader><CardTitle>Changer le mot de passe</CardTitle></CardHeader>
          <CardContent className="space-y-3 max-w-sm">
            {pwdError && <p className="text-sm text-red-600">{pwdError}</p>}
            <div>
              <label className="text-sm font-medium mb-1.5 block">Nouveau mot de passe</label>
              <input type="password" className="input" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} />
            </div>
            <div>
              <label className="text-sm font-medium mb-1.5 block">Confirmer le mot de passe</label>
              <input type="password" className="input" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} />
            </div>
            <div className="flex items-center gap-3">
              <Button size="sm" onClick={changePassword} disabled={savingPwd}>{savingPwd ? "…" : "Mettre à jour"}</Button>
              {pwdSaved && <span className="text-xs text-emerald-600">Mot de passe modifié ✓</span>}
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardShell>
  );
}
