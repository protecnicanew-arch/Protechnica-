"use client";

import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Plus, Trash2, BookOpen, Search } from "lucide-react";
import { DashboardShell } from "@/components/layout/DashboardShell";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog } from "@/components/ui/dialog";
import { listResources, createResource, deleteResource, toggleDisponibilite, type LibraryResource } from "@/lib/services/library.service";
import { useSession } from "@/lib/auth/use-session";
import { can } from "@/lib/auth/permissions";

const schema = z.object({
  titre: z.string().min(2, "Titre requis"),
  auteur: z.string().optional(),
  categorie: z.string().optional(),
});
type FormValues = z.infer<typeof schema>;

export default function BibliothequePage() {
  const { profile } = useSession();
  const [items, setItems] = useState<LibraryResource[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [open, setOpen] = useState(false);
  const { register, handleSubmit, reset, formState: { errors } } = useForm<FormValues>({ resolver: zodResolver(schema) });

  const reload = () => {
    setLoading(true);
    listResources().then((rows) => {
      setItems(rows);
      setLoading(false);
    });
  };
  useEffect(reload, []);

  const canWrite = profile ? can(profile.role, "bibliotheque", "creer") : false;
  const filtered = items.filter(
    (r) => search.trim() === "" || r.titre.toLowerCase().includes(search.toLowerCase()) || r.auteur?.toLowerCase().includes(search.toLowerCase())
  );

  const submit = async (data: FormValues) => {
    await createResource(data);
    reset();
    setOpen(false);
    reload();
  };

  return (
    <DashboardShell title="Bibliothèque">
      <div className="flex items-center justify-between mb-5">
        <p className="text-sm text-muted-foreground">Ouvrages et ressources disponibles pour emprunt.</p>
        {canWrite && (
          <Button onClick={() => setOpen(true)} className="gap-1.5">
            <Plus className="h-4 w-4" /> Nouvelle ressource
          </Button>
        )}
      </div>

      <div className="flex items-center gap-2 rounded-lg border border-border bg-background px-3 py-2 mb-5 max-w-md">
        <Search className="h-4 w-4 text-muted-foreground shrink-0" />
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Rechercher un titre ou un auteur…"
          className="w-full bg-transparent text-sm outline-none placeholder:text-muted-foreground"
        />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
        {filtered.map((r) => (
          <Card key={r.id}>
            <CardContent className="pt-5">
              <div className="flex items-start justify-between mb-2">
                <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                  <BookOpen className="h-5 w-5 text-primary" />
                </div>
                <Badge variant={r.disponible ? "success" : "destructive"}>
                  {r.disponible ? "Disponible" : "Emprunté"}
                </Badge>
              </div>
              <h3 className="font-semibold mb-1">{r.titre}</h3>
              <p className="text-xs text-muted-foreground mb-3">{r.auteur ?? "Auteur inconnu"} {r.categorie ? `· ${r.categorie}` : ""}</p>
              {canWrite && (
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" className="flex-1" onClick={() => toggleDisponibilite(r.id, !r.disponible).then(reload)}>
                    Marquer {r.disponible ? "emprunté" : "disponible"}
                  </Button>
                  <Button variant="ghost" size="sm" className="text-red-600 hover:text-red-700" onClick={() => { if (confirm(`Supprimer "${r.titre}" ?`)) deleteResource(r.id).then(reload); }}>
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
        {!loading && filtered.length === 0 && (
          <p className="text-sm text-muted-foreground col-span-full text-center py-8">Aucune ressource trouvée.</p>
        )}
      </div>

      <Dialog open={open} onClose={() => setOpen(false)} title="Nouvelle ressource">
        <form onSubmit={handleSubmit(submit)} className="space-y-4">
          <div>
            <label className="text-sm font-medium mb-1.5 block">Titre</label>
            <input className="input" {...register("titre")} />
            {errors.titre && <p className="text-xs text-red-600 mt-1">{errors.titre.message}</p>}
          </div>
          <div>
            <label className="text-sm font-medium mb-1.5 block">Auteur</label>
            <input className="input" {...register("auteur")} />
          </div>
          <div>
            <label className="text-sm font-medium mb-1.5 block">Catégorie</label>
            <input className="input" placeholder="Ex: Informatique, Gestion…" {...register("categorie")} />
          </div>
          <div className="flex gap-2 pt-2">
            <Button type="button" variant="outline" className="flex-1" onClick={() => setOpen(false)}>Annuler</Button>
            <Button type="submit" className="flex-1">Ajouter</Button>
          </div>
        </form>
      </Dialog>
    </DashboardShell>
  );
}
