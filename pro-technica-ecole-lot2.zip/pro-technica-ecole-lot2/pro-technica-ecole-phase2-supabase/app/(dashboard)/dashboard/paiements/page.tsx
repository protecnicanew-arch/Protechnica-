"use client";

import { useEffect, useMemo, useState } from "react";
import { Plus, Search, Wallet } from "lucide-react";
import { DashboardShell } from "@/components/layout/DashboardShell";
import { Button } from "@/components/ui/button";
import { PaymentStatusBadge } from "@/components/students/StatusBadges";
import { PaymentFormDialog } from "@/components/payments/PaymentFormDialog";
import { InstallmentFormDialog } from "@/components/payments/InstallmentFormDialog";
import { listAllPayments, createPayment, recordInstallment } from "@/lib/services/payments.service";
import { useSession } from "@/lib/auth/use-session";
import { useAcademicStore } from "@/lib/store";
import type { Payment } from "@/lib/types";
import { formatCFA, formatDate } from "@/lib/utils";

export default function PaiementsPage() {
  const { students } = useAcademicStore();
  const { profile } = useSession();
  const [payments, setPayments] = useState<Payment[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("tous");
  const [createOpen, setCreateOpen] = useState(false);
  const [encaissement, setEncaissement] = useState<Payment | null>(null);

  const reload = () => {
    setLoading(true);
    listAllPayments().then((p) => {
      setPayments(p);
      setLoading(false);
    });
  };

  useEffect(reload, []);

  const studentName = (id: string) => students.find((s) => s.id === id)?.fullName ?? "—";
  const studentMatricule = (id: string) => students.find((s) => s.id === id)?.matricule ?? "";

  const filtered = useMemo(() => {
    return payments.filter((p) => {
      const name = studentName(p.studentId).toLowerCase();
      const matchSearch = search.trim() === "" || name.includes(search.toLowerCase()) || p.libelle.toLowerCase().includes(search.toLowerCase());
      const matchStatus = statusFilter === "tous" || p.status === statusFilter;
      return matchSearch && matchStatus;
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [payments, search, statusFilter, students]);

  const totalDu = filtered.reduce((s, p) => s + p.montantDu, 0);
  const totalPaye = filtered.reduce((s, p) => s + p.montantPaye, 0);

  return (
    <DashboardShell title="Paiements">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5">
        <p className="text-sm text-muted-foreground">Facturation, encaissements et suivi des soldes.</p>
        <Button onClick={() => setCreateOpen(true)} className="gap-1.5">
          <Plus className="h-4 w-4" /> Nouveau paiement
        </Button>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-2 gap-4 mb-5">
        <div className="rounded-xl border border-border bg-card px-4 py-3.5">
          <p className="text-xs text-muted-foreground mb-1">Total facturé</p>
          <p className="text-lg font-semibold">{formatCFA(totalDu)}</p>
        </div>
        <div className="rounded-xl border border-border bg-card px-4 py-3.5">
          <p className="text-xs text-muted-foreground mb-1">Total encaissé</p>
          <p className="text-lg font-semibold text-emerald-600">{formatCFA(totalPaye)}</p>
        </div>
      </div>

      <div className="flex flex-col sm:flex-row gap-3 mb-4">
        <div className="flex items-center gap-2 rounded-lg border border-border bg-background px-3 py-2 flex-1">
          <Search className="h-4 w-4 text-muted-foreground shrink-0" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Rechercher par étudiant ou libellé…"
            className="w-full bg-transparent text-sm outline-none placeholder:text-muted-foreground"
          />
        </div>
        <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className="input sm:w-56">
          <option value="tous">Tous les statuts</option>
          <option value="paye">Payé</option>
          <option value="partiel">Partiel</option>
          <option value="impaye">Impayé</option>
          <option value="en_retard">En retard</option>
        </select>
      </div>

      <div className="overflow-x-auto rounded-xl border border-border bg-card">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border text-left text-muted-foreground">
              <th className="px-4 py-3 font-medium">Étudiant</th>
              <th className="px-4 py-3 font-medium">Libellé</th>
              <th className="px-4 py-3 font-medium">Dû</th>
              <th className="px-4 py-3 font-medium">Payé</th>
              <th className="px-4 py-3 font-medium">Statut</th>
              <th className="px-4 py-3 font-medium"></th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((p) => (
              <tr key={p.id} className="border-b border-border last:border-0 hover:bg-muted/40">
                <td className="px-4 py-3 whitespace-nowrap">
                  <p className="font-medium">{studentName(p.studentId)}</p>
                  <p className="text-xs text-muted-foreground">{studentMatricule(p.studentId)}</p>
                </td>
                <td className="px-4 py-3 whitespace-nowrap">{p.libelle}</td>
                <td className="px-4 py-3 whitespace-nowrap">{formatCFA(p.montantDu)}</td>
                <td className="px-4 py-3 whitespace-nowrap text-emerald-600">{formatCFA(p.montantPaye)}</td>
                <td className="px-4 py-3 whitespace-nowrap"><PaymentStatusBadge status={p.status} /></td>
                <td className="px-4 py-3 text-right">
                  {p.status !== "paye" && (
                    <Button variant="outline" size="sm" className="gap-1.5" onClick={() => setEncaissement(p)}>
                      <Wallet className="h-3.5 w-3.5" /> Encaisser
                    </Button>
                  )}
                </td>
              </tr>
            ))}
            {!loading && filtered.length === 0 && (
              <tr><td colSpan={6} className="text-center py-8 text-muted-foreground">Aucun paiement trouvé.</td></tr>
            )}
            {loading && (
              <tr><td colSpan={6} className="text-center py-8 text-muted-foreground">Chargement…</td></tr>
            )}
          </tbody>
        </table>
      </div>

      <PaymentFormDialog
        open={createOpen}
        onClose={() => setCreateOpen(false)}
        students={students}
        onSubmit={async (data) => {
          await createPayment(data);
          reload();
        }}
      />

      <InstallmentFormDialog
        open={!!encaissement}
        onClose={() => setEncaissement(null)}
        payment={encaissement}
        onSubmit={async (data) => {
          if (!encaissement || !profile) return;
          await recordInstallment({
            paymentId: encaissement.id,
            montant: data.montant,
            modePaiement: data.modePaiement,
            encaissePar: profile.id,
          });
          reload();
        }}
      />
    </DashboardShell>
  );
}
