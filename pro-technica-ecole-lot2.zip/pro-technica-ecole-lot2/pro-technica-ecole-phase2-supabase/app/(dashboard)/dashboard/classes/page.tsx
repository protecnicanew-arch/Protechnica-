"use client";

import { useState } from "react";
import Link from "next/link";
import { Plus, Pencil, Trash2, Eye } from "lucide-react";
import { DashboardShell } from "@/components/layout/DashboardShell";
import { Button } from "@/components/ui/button";
import { ClasseFormDialog } from "@/components/academic/ClasseFormDialog";
import { useAcademicStore } from "@/lib/store";
import type { Classe } from "@/lib/types";

export default function ClassesPage() {
  const { classes, filieres, students, teachers, addClasse, updateClasse, deleteClasse } = useAcademicStore();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<Classe | undefined>(undefined);

  const filiereName = (id: string) => filieres.find((f) => f.id === id)?.nom ?? "—";
  const effectifActuel = (classeId: string) => students.filter((s) => s.classeId === classeId).length;
  const profName = (id?: string) => teachers.find((t) => t.id === id)?.fullName ?? "Non assigné";

  const openCreate = () => { setEditing(undefined); setDialogOpen(true); };
  const openEdit = (c: Classe) => { setEditing(c); setDialogOpen(true); };

  const handleSubmit = (data: Omit<Classe, "id">) => {
    if (editing) updateClasse(editing.id, data);
    else addClasse(data);
  };

  const handleDelete = (c: Classe) => {
    if (effectifActuel(c.id) > 0) {
      alert("Impossible de supprimer : des étudiants sont encore affectés à cette classe.");
      return;
    }
    if (confirm(`Supprimer la classe "${c.nom}" ?`)) deleteClasse(c.id);
  };

  return (
    <DashboardShell title="Classes">
      <div className="flex items-center justify-between mb-5">
        <p className="text-sm text-muted-foreground">
          Création, effectifs et affectation des enseignants principaux.
        </p>
        <Button onClick={openCreate} className="gap-1.5">
          <Plus className="h-4 w-4" /> Nouvelle classe
        </Button>
      </div>

      <div className="overflow-x-auto rounded-xl border border-border bg-card">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border text-left text-muted-foreground">
              <th className="px-4 py-3 font-medium">Classe</th>
              <th className="px-4 py-3 font-medium">Filière</th>
              <th className="px-4 py-3 font-medium">Année</th>
              <th className="px-4 py-3 font-medium">Effectif</th>
              <th className="px-4 py-3 font-medium">Prof. principal</th>
              <th className="px-4 py-3 font-medium"></th>
            </tr>
          </thead>
          <tbody>
            {classes.map((c) => (
              <tr key={c.id} className="border-b border-border last:border-0 hover:bg-muted/40">
                <td className="px-4 py-3 font-medium whitespace-nowrap">{c.nom}</td>
                <td className="px-4 py-3 whitespace-nowrap">{filiereName(c.filiereId)}</td>
                <td className="px-4 py-3 whitespace-nowrap">{c.anneeScolaire}</td>
                <td className="px-4 py-3 whitespace-nowrap">{effectifActuel(c.id)} / {c.effectifMax}</td>
                <td className="px-4 py-3 whitespace-nowrap">{profName(c.professeurPrincipalId)}</td>
                <td className="px-4 py-3">
                  <div className="flex items-center gap-1 justify-end">
                    <Link href={`/dashboard/classes/${c.id}`}>
                      <Button variant="ghost" size="sm" className="gap-1.5"><Eye className="h-3.5 w-3.5" /> Gérer</Button>
                    </Link>
                    <Button variant="ghost" size="icon" onClick={() => openEdit(c)}><Pencil className="h-3.5 w-3.5" /></Button>
                    <Button variant="ghost" size="icon" className="text-red-600 hover:text-red-700" onClick={() => handleDelete(c)}>
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </td>
              </tr>
            ))}
            {classes.length === 0 && (
              <tr><td colSpan={6} className="text-center py-8 text-muted-foreground">Aucune classe créée.</td></tr>
            )}
          </tbody>
        </table>
      </div>

      <ClasseFormDialog
        open={dialogOpen}
        onClose={() => setDialogOpen(false)}
        onSubmit={handleSubmit}
        initial={editing}
        filieres={filieres}
      />
    </DashboardShell>
  );
}
