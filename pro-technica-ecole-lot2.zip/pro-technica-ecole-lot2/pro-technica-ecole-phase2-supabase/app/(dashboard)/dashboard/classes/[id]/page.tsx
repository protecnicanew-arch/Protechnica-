"use client";

import { useParams, useRouter } from "next/navigation";
import { ArrowLeft, UserCheck } from "lucide-react";
import { DashboardShell } from "@/components/layout/DashboardShell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useAcademicStore } from "@/lib/store";

export default function ClasseDetailPage() {
  const params = useParams<{ id: string }>();
  const router = useRouter();
  const {
    classes, filieres, students, teachers, assignProfesseurPrincipal, reassignStudentClasse,
  } = useAcademicStore();

  const classe = classes.find((c) => c.id === params.id);

  if (!classe) {
    return (
      <DashboardShell title="Classe introuvable">
        <p className="text-sm text-muted-foreground mb-4">Cette classe n'existe pas ou a été supprimée.</p>
        <Button variant="outline" onClick={() => router.push("/dashboard/classes")} className="gap-1.5">
          <ArrowLeft className="h-4 w-4" /> Retour aux classes
        </Button>
      </DashboardShell>
    );
  }

  const filiere = filieres.find((f) => f.id === classe.filiereId);
  const studentsInClasse = students.filter((s) => s.classeId === classe.id);
  const studentsAvailable = students.filter((s) => s.classeId !== classe.id);

  return (
    <DashboardShell title="Gestion de la classe">
      <Button variant="ghost" size="sm" className="gap-1.5 mb-4 -ml-2" onClick={() => router.push("/dashboard/classes")}>
        <ArrowLeft className="h-4 w-4" /> Retour aux classes
      </Button>

      <Card className="mb-6">
        <CardContent className="pt-6">
          <h2 className="text-lg font-semibold">{classe.nom}</h2>
          <p className="text-sm text-muted-foreground">
            {filiere?.nom} · {classe.anneeScolaire} · {studentsInClasse.length}/{classe.effectifMax} étudiants
          </p>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
        <Card>
          <CardHeader><CardTitle>Professeur principal</CardTitle></CardHeader>
          <CardContent>
            <select
              value={classe.professeurPrincipalId ?? ""}
              onChange={(e) => assignProfesseurPrincipal(classe.id, e.target.value || undefined)}
              className="w-full rounded-lg border border-border bg-background px-3 py-2.5 text-sm outline-none"
            >
              <option value="">Non assigné</option>
              {teachers.map((t) => (
                <option key={t.id} value={t.id}>{t.fullName}</option>
              ))}
            </select>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>Étudiants de la classe ({studentsInClasse.length})</CardTitle></CardHeader>
          <CardContent className="space-y-2 max-h-72 overflow-y-auto">
            {studentsInClasse.length === 0 && (
              <p className="text-sm text-muted-foreground">Aucun étudiant affecté pour l'instant.</p>
            )}
            {studentsInClasse.map((s) => (
              <div key={s.id} className="flex items-center justify-between rounded-lg border border-border px-3 py-2 text-sm">
                <span>{s.fullName} <span className="text-xs text-muted-foreground">· {s.matricule}</span></span>
                <UserCheck className="h-4 w-4 text-emerald-600" />
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      <Card className="mt-4">
        <CardHeader><CardTitle>Affecter un étudiant à cette classe</CardTitle></CardHeader>
        <CardContent className="space-y-2 max-h-72 overflow-y-auto">
          {studentsAvailable.length === 0 && (
            <p className="text-sm text-muted-foreground">Tous les étudiants sont déjà dans cette classe.</p>
          )}
          {studentsAvailable.map((s) => (
            <div key={s.id} className="flex items-center justify-between rounded-lg border border-border px-3 py-2 text-sm">
              <span>{s.fullName} <span className="text-xs text-muted-foreground">· actuellement dans une autre classe</span></span>
              <Button size="sm" variant="outline" onClick={() => reassignStudentClasse(s.id, classe.id)}>
                Affecter ici
              </Button>
            </div>
          ))}
        </CardContent>
      </Card>
    </DashboardShell>
  );
}
