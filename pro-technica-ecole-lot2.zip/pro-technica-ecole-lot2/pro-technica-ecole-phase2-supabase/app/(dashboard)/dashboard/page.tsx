"use client";

import { useEffect, useState } from "react";
import {
  AreaChart, Area, BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid,
} from "recharts";
import { TrendingUp, TrendingDown, Users, GraduationCap, UserCheck, Wallet } from "lucide-react";
import { DashboardShell } from "@/components/layout/DashboardShell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  getDashboardStats, getRevenueSeries, getEnrollmentByFiliere, getActivityLog,
} from "@/lib/data";
import type { DashboardStats, ActivityLogEntry } from "@/lib/types";
import { formatCFA, percentChange, formatDate } from "@/lib/utils";

export default function DashboardPage() {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [revenue, setRevenue] = useState<{ mois: string; revenus: number }[]>([]);
  const [enrollment, setEnrollment] = useState<{ filiere: string; etudiants: number }[]>([]);
  const [activity, setActivity] = useState<ActivityLogEntry[]>([]);

  useEffect(() => {
    getDashboardStats().then(setStats);
    getRevenueSeries().then(setRevenue);
    getEnrollmentByFiliere().then(setEnrollment);
    getActivityLog().then(setActivity);
  }, []);

  const revenueChange = stats ? percentChange(stats.revenusMois, stats.revenusMoisPrecedent) : 0;
  const studentChange = stats ? percentChange(stats.etudiantsInscrits, stats.etudiantsMoisPrecedent) : 0;

  const statCards = stats
    ? [
        {
          label: "Revenus du mois", value: formatCFA(stats.revenusMois), change: revenueChange,
          icon: Wallet,
        },
        {
          label: "Étudiants inscrits", value: stats.etudiantsInscrits.toString(), change: studentChange,
          icon: GraduationCap,
        },
        {
          label: "Professeurs actifs", value: stats.professeursActifs.toString(), change: null,
          icon: Users,
        },
        {
          label: "Taux de présence", value: `${stats.tauxPresenceMoyen}%`, change: null,
          icon: UserCheck,
        },
      ]
    : [];

  return (
    <DashboardShell title="Tableau de bord">
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
        {statCards.map((card) => {
          const Icon = card.icon;
          const positive = (card.change ?? 0) >= 0;
          return (
            <Card key={card.label} className="hover:shadow-elevated transition-shadow">
              <CardContent className="pt-5 flex items-start justify-between">
                <div>
                  <p className="text-xs text-muted-foreground mb-1">{card.label}</p>
                  <p className="text-2xl font-semibold">{card.value}</p>
                  {card.change !== null && (
                    <div className={`flex items-center gap-1 mt-1 text-xs font-medium ${positive ? "text-emerald-600" : "text-red-600"}`}>
                      {positive ? <TrendingUp className="h-3.5 w-3.5" /> : <TrendingDown className="h-3.5 w-3.5" />}
                      {Math.abs(card.change).toFixed(1)}% vs mois dernier
                    </div>
                  )}
                </div>
                <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                  <Icon className="h-5 w-5 text-primary" />
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4 mb-6">
        <Card className="xl:col-span-2">
          <CardHeader>
            <CardTitle>Évolution des revenus</CardTitle>
          </CardHeader>
          <CardContent className="pl-0">
            <ResponsiveContainer width="100%" height={260}>
              <AreaChart data={revenue} margin={{ left: 8, right: 16 }}>
                <defs>
                  <linearGradient id="revenueFill" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#E10600" stopOpacity={0.25} />
                    <stop offset="100%" stopColor="#E10600" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} className="stroke-border" />
                <XAxis dataKey="mois" tickLine={false} axisLine={false} fontSize={12} />
                <YAxis
                  tickLine={false}
                  axisLine={false}
                  fontSize={12}
                  tickFormatter={(v) => `${(v / 1_000_000).toFixed(0)}M`}
                />
                <Tooltip formatter={(v: number) => formatCFA(v)} />
                <Area type="monotone" dataKey="revenus" stroke="#E10600" strokeWidth={2} fill="url(#revenueFill)" />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Répartition par filière</CardTitle>
          </CardHeader>
          <CardContent className="pl-0">
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={enrollment} layout="vertical" margin={{ left: 8, right: 16 }}>
                <XAxis type="number" hide />
                <YAxis
                  type="category"
                  dataKey="filiere"
                  tickLine={false}
                  axisLine={false}
                  fontSize={11}
                  width={110}
                />
                <Tooltip />
                <Bar dataKey="etudiants" fill="#111111" radius={[0, 6, 6, 0]} barSize={18} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Activité récente</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {activity.map((entry) => (
            <div key={entry.id} className="flex items-start gap-3 text-sm">
              <div className="h-8 w-8 rounded-full bg-muted flex items-center justify-center text-xs font-semibold shrink-0">
                {entry.userName.charAt(0)}
              </div>
              <div className="flex-1">
                <p>
                  <span className="font-medium">{entry.userName}</span>{" "}
                  <span className="text-muted-foreground">{entry.action}</span>
                </p>
                <p className="text-xs text-muted-foreground">{formatDate(entry.date)}</p>
              </div>
            </div>
          ))}
          {activity.length === 0 && (
            <Badge variant="outline">Aucune activité récente</Badge>
          )}
        </CardContent>
      </Card>
    </DashboardShell>
  );
}
