"use client";

import { useState } from "react";
import { DashboardShell } from "@/components/layout/DashboardShell";
import { GradeEntryForm } from "@/components/grades/GradeEntryForm";
import { ClassRanking } from "@/components/grades/ClassRanking";

type Tab = "saisie" | "classement";

export default function NotesPage() {
  const [tab, setTab] = useState<Tab>("saisie");

  const tabs: { id: Tab; label: string }[] = [
    { id: "saisie", label: "Saisie des notes" },
    { id: "classement", label: "Classement & moyennes" },
  ];

  return (
    <DashboardShell title="Notes & Examens">
      <div className="flex gap-1 border-b border-border mb-5 overflow-x-auto">
        {tabs.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`px-4 py-2.5 text-sm font-medium whitespace-nowrap border-b-2 -mb-px transition-colors ${
              tab === t.id ? "border-primary text-primary" : "border-transparent text-muted-foreground hover:text-foreground"
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {tab === "saisie" && <GradeEntryForm />}
      {tab === "classement" && <ClassRanking />}
    </DashboardShell>
  );
}
