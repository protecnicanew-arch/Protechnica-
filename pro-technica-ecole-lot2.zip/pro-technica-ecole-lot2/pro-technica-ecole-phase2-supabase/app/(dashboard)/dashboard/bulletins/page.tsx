"use client";

import { useEffect, useMemo, useState } from "react";
import { FileText, RefreshCw, Download } from "lucide-react";
import { DashboardShell } from "@/components/layout/DashboardShell";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useAcademicStore } from "@/lib/store";
import {
  generateReportCardsForClasse, listReportCards, listGradesForClasse, type ReportCardRow,
} from "@/lib/services/grades.service";
import type { Grade } from "@/lib/types";
import { formatDate } from "@/lib/utils";

const PERIODES = ["Trimestre 1", "Trimestre 2", "Trimestre 3"];

export default function BulletinsPage() {
  const { classes, students, init } = useAcademicStore();
  const [classeId, setClasseId] = useState("");
  const [periode, setPeriode] = useState(PERIODES[0]);
  const [rows, setRows] = useState<ReportCardRow[]>([]);
  const [grades, setGrades] = useState<Grade[]>([]);
  const [generating, setGenerating] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => { init(); }, [init]);
  useEffect(() => {
    if (!classeId && classes.length > 0) setClasseId(classes[0].id);
  }, [classes, classeId]);

  const classStudents = useMemo(() => students.filter((s) => s.classeId === classeId), [students, classeId]);

  const reload = () => {
    if (!classeId) return;
    setLoading(true);
    listReportCards(classStudents.map((s) => s.id), periode).then((r) => {
      setRows(r);
      setLoading(false);
    });
  };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(reload, [classeId, periode, classStudents.length]);

  const generateAll = async () => {
    if (!classeId) return;
    setGenerating(true);
    await generateReportCardsForClasse(classeId, periode, classStudents.map((s) => s.id));
    const g = await listGradesForClasse(classeId, periode);
    setGrades(g);
    setGenerating(false);
    reload();
  };

  const downloadPdf = async (studentId: string, row: ReportCardRow) => {
    const student = classStudents.find((s) => s.id === studentId);
    if (!student) return;
    const classe = classes.find((c) => c.id === classeId);

    const { default: jsPDF } = await import("jspdf");
    const autoTable = (await import("jspdf-autotable")).default;

    const doc = new jsPDF();
    doc.setFontSize(16);
    doc.text("PRO TECHNICA ÉCOLE — Bulletin de notes", 14, 18);
    doc.setFontSize(10);
    doc.text(`Étudiant : ${student.fullName} (${student.matricule})`, 14, 28);
    doc.text(`Classe : ${classe?.nom ?? "—"}`, 14, 34);
    doc.text(`Période : ${row.periode}`, 14, 40);
    doc.text(`Généré le ${formatDate(new Date().toISOString())}`, 14, 46);

    const studentGrades = grades.filter((g) => g.studentId === studentId);
    autoTable(doc, {
      startY: 54,
      head: [["Matière", "Type", "Note", "Barème", "Coefficient"]],
      body: studentGrades.map((g) => [g.matiere, g.type, g.note, g.bareme, g.coefficient]),
    });

    const finalY = (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY ?? 60;
    doc.setFontSize(11);
    doc.text(`Moyenne générale : ${row.moyenneGenerale?.toFixed(2) ?? "—"}/20`, 14, finalY + 10);
    doc.text(`Rang : ${row.rang ?? "—"} / ${row.effectifClasse ?? "—"}`, 14, finalY + 16);

    doc.save(`bulletin-${student.matricule}-${row.periode.replace(" ", "-")}.pdf`);
  };

  return (
    <DashboardShell title="Bulletins">
      <div className="flex flex-col sm:flex-row sm:items-center gap-3 mb-5">
        <p className="text-sm text-muted-foreground flex-1">
          Génère la moyenne, le rang et le bulletin PDF de chaque étudiant.
        </p>
        <select className="input sm:w-56" value={classeId} onChange={(e) => setClasseId(e.target.value)}>
          {classes.map((c) => <option key={c.id} value={c.id}>{c.nom}</option>)}
        </select>
        <select className="input sm:w-44" value={periode} onChange={(e) => setPeriode(e.target.value)}>
          {PERIODES.map((p) => <option key={p} value={p}>{p}</option>)}
        </select>
        <Button onClick={generateAll} disabled={generating || !classeId} className="gap-1.5 shrink-0">
          <RefreshCw className={`h-4 w-4 ${generating ? "animate-spin" : ""}`} /> Générer la classe
        </Button>
      </div>

      <div className="overflow-x-auto rounded-xl border border-border bg-card">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border text-left text-muted-foreground">
              <th className="px-4 py-3 font-medium">Étudiant</th>
              <th className="px-4 py-3 font-medium">Moyenne</th>
              <th className="px-4 py-3 font-medium">Rang</th>
              <th className="px-4 py-3 font-medium"></th>
            </tr>
          </thead>
          <tbody>
            {classStudents.map((s) => {
              const row = rows.find((r) => r.studentId === s.id);
              return (
                <tr key={s.id} className="border-b border-border last:border-0 hover:bg-muted/40">
                  <td className="px-4 py-3 whitespace-nowrap font-medium">{s.fullName}</td>
                  <td className="px-4 py-3 whitespace-nowrap">
                    {row?.moyenneGenerale != null ? (
                      <span className="font-semibold">{row.moyenneGenerale.toFixed(2)}/20</span>
                    ) : (
                      <Badge variant="outline">Non généré</Badge>
                    )}
                  </td>
                  <td className="px-4 py-3 whitespace-nowrap">
                    {row?.rang ? `${row.rang} / ${row.effectifClasse}` : "—"}
                  </td>
                  <td className="px-4 py-3 text-right">
                    {row?.moyenneGenerale != null && (
                      <Button variant="outline" size="sm" className="gap-1.5" onClick={() => downloadPdf(s.id, row)}>
                        <Download className="h-3.5 w-3.5" /> PDF
                      </Button>
                    )}
                  </td>
                </tr>
              );
            })}
            {!loading && classStudents.length === 0 && (
              <tr><td colSpan={4} className="text-center py-8 text-muted-foreground">Aucun étudiant dans cette classe.</td></tr>
            )}
          </tbody>
        </table>
      </div>

      <p className="text-xs text-muted-foreground mt-3 flex items-center gap-1.5">
        <FileText className="h-3.5 w-3.5" /> « Générer la classe » calcule la moyenne pondérée et le classement à partir des notes déjà saisies dans le module Notes & Examens.
      </p>
    </DashboardShell>
  );
}
