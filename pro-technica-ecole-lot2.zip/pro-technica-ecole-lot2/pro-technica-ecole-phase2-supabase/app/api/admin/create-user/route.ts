import { NextRequest, NextResponse } from "next/server";
import { createClient as createServerClient, createAdminClient } from "@/lib/supabase/server";

// ============================================================
// Création de compte étudiant / professeur par un administrateur.
//
// Pourquoi une route serveur (et pas juste supabase.auth.signUp() côté
// client, comme le fait la page /login) : signUp() côté navigateur ouvre
// automatiquement une session pour le NOUVEAU compte créé, ce qui aurait
// pour effet de déconnecter l'administrateur en train de créer la fiche.
// On utilise donc la clé service_role côté serveur (auth.admin.createUser)
// pour créer le compte sans jamais toucher à la session de l'appelant.
// ============================================================

type Payload = {
  role: "etudiant" | "professeur";
  fullName: string;
  email: string;
  password: string;
  phone?: string;
  // étudiant
  matricule?: string;
  classeId?: string;
  programId?: string;
  dateNaissance?: string;
  // professeur
  specialite?: string;
  dateEmbauche?: string;
  matiereIds?: string[];
  classeIds?: string[];
};

export async function POST(request: NextRequest) {
  // 1. Vérifie que l'appelant est bien authentifié et a le rôle requis.
  const supabase = await createServerClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) {
    return NextResponse.json({ error: "Non authentifié." }, { status: 401 });
  }

  const { data: callerProfile } = await supabase.from("profiles").select("role").eq("id", user.id).single();
  if (!callerProfile || !["administrateur", "direction"].includes(callerProfile.role)) {
    return NextResponse.json({ error: "Action réservée à l'administration." }, { status: 403 });
  }

  const body = (await request.json()) as Payload;
  if (!body.email || !body.password || !body.fullName || !body.role) {
    return NextResponse.json({ error: "Champs requis manquants." }, { status: 400 });
  }

  const admin = await createAdminClient();

  // 2. Crée le compte Auth + le profil (via le trigger handle_new_user).
  const { data: created, error: createError } = await admin.auth.admin.createUser({
    email: body.email,
    password: body.password,
    email_confirm: true,
    user_metadata: { full_name: body.fullName, role: body.role, phone: body.phone },
  });
  if (createError || !created.user) {
    return NextResponse.json({ error: createError?.message ?? "Échec de la création du compte." }, { status: 400 });
  }

  const profileId = created.user.id;

  // 3. Ligne métier (students / teachers), selon le rôle.
  try {
    if (body.role === "etudiant") {
      if (!body.matricule || !body.classeId || !body.programId) {
        throw new Error("Matricule, classe et filière sont requis pour un étudiant.");
      }
      const { error } = await admin.from("students").insert({
        id: profileId,
        matricule: body.matricule,
        classe_id: body.classeId,
        program_id: body.programId,
        date_naissance: body.dateNaissance,
      });
      if (error) throw error;
    } else {
      if (!body.matricule) {
        throw new Error("Le matricule est requis pour un professeur.");
      }
      const { error } = await admin.from("teachers").insert({
        id: profileId,
        matricule: body.matricule,
        specialite: body.specialite,
        date_embauche: body.dateEmbauche,
      });
      if (error) throw error;

      if (body.matiereIds?.length) {
        await admin
          .from("teacher_subjects")
          .insert(body.matiereIds.map((subjectId) => ({ teacher_id: profileId, subject_id: subjectId })));
      }
      if (body.classeIds?.length) {
        await admin
          .from("teacher_classes")
          .insert(body.classeIds.map((classeId) => ({ teacher_id: profileId, classe_id: classeId })));
      }
    }
  } catch (err) {
    // Ligne métier échouée : on retire le compte Auth orphelin pour ne pas
    // laisser un profil "fantôme" sans fiche étudiant/professeur associée.
    await admin.auth.admin.deleteUser(profileId);
    const message = err instanceof Error ? err.message : "Erreur lors de la création de la fiche.";
    return NextResponse.json({ error: message }, { status: 400 });
  }

  return NextResponse.json({ id: profileId });
}
