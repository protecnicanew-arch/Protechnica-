"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { Search, Mail, Phone, Eye } from "lucide-react";
import type { Teacher, Classe } from "@/lib/types";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { formatDate } from "@/lib/utils";

export function TeachersGrid({ teachers, classes }: { teachers: Teacher[]; classes: Classe[] }) {
  const [search, setSearch] = useState("");

  const filtered = useMemo(() => {
    return teachers.filter(
      (t) =>
        search.trim() === "" ||
        t.fullName.toLowerCase().includes(search.toLowerCase()) ||
        t.matieres.some((m) => m.toLowerCase().includes(search.toLowerCase()))
    );
  }, [teachers, search]);

  const classNames = (ids: string[]) =>
    ids.map((id) => classes.find((c) => c.id === id)?.nom).filter(Boolean).join(", ");

  return (
    <div>
      <div className="flex items-center gap-2 rounded-lg border border-border bg-background px-3 py-2 mb-5 max-w-md">
        <Search className="h-4 w-4 text-muted-foreground shrink-0" />
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Rechercher par nom ou matière…"
          className="w-full bg-transparent text-sm outline-none placeholder:text-muted-foreground"
        />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
        {filtered.map((t) => (
          <Card key={t.id} className="hover:shadow-elevated transition-shadow">
            <CardContent className="pt-5">
              <div className="flex items-start gap-3 mb-3">
                <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center text-sm font-semibold text-primary shrink-0">
                  {t.fullName.split(" ").map((n) => n[0]).join("").slice(0, 2)}
                </div>
                <div className="min-w-0">
                  <p className="font-medium truncate">{t.fullName}</p>
                  <p className="text-xs text-muted-foreground">Depuis {formatDate(t.dateEmbauche)}</p>
                </div>
              </div>

              <div className="flex flex-wrap gap-1.5 mb-3">
                {t.matieres.map((m) => (
                  <Badge key={m} variant="outline">{m}</Badge>
                ))}
              </div>

              <div className="space-y-1 text-xs text-muted-foreground mb-4">
                <p className="flex items-center gap-1.5"><Mail className="h-3.5 w-3.5" /> {t.email}</p>
                <p className="flex items-center gap-1.5"><Phone className="h-3.5 w-3.5" /> {t.phone}</p>
                <p className="truncate">Classes : {classNames(t.classesIds) || "—"}</p>
              </div>

              <Link href={`/dashboard/professeurs/${t.id}`}>
                <Button variant="outline" size="sm" className="w-full gap-1.5">
                  <Eye className="h-3.5 w-3.5" /> Voir le profil
                </Button>
              </Link>
            </CardContent>
          </Card>
        ))}

        {filtered.length === 0 && (
          <p className="text-sm text-muted-foreground col-span-full text-center py-8">
            Aucun professeur ne correspond à votre recherche.
          </p>
        )}
      </div>
    </div>
  );
}
