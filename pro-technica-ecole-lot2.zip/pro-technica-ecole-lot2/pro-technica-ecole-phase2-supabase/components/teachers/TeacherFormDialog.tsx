"use client";

import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import type { Classe } from "@/lib/types";

function generatePassword() {
  return `PT-${Math.random().toString(36).slice(2, 6)}${Math.floor(Math.random() * 100)}!`;
}

const schema = z.object({
  fullName: z.string().min(2, "Nom complet requis"),
  email: z.string().email("Email invalide"),
  phone: z.string().optional(),
  matricule: z.string().min(2, "Matricule requis"),
  specialite: z.string().optional(),
  dateEmbauche: z.string().optional(),
  classeIds: z.array(z.string()).default([]),
  matiereIds: z.array(z.string()).default([]),
  password: z.string().min(6, "6 caractères minimum"),
});
type FormValues = z.infer<typeof schema>;

export function TeacherFormDialog({
  classes,
  subjects,
  onSubmit,
}: {
  classes: Classe[];
  subjects: { id: string; nom: string }[];
  onSubmit: (data: FormValues) => Promise<void>;
}) {
  const [submitting, setSubmitting] = useState(false);
  const [serverError, setServerError] = useState<string | null>(null);
  const {
    register,
    handleSubmit,
    setValue,
    watch,
    formState: { errors },
  } = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: { password: generatePassword(), classeIds: [], matiereIds: [] },
  });

  const selectedClasses = watch("classeIds");
  const selectedSubjects = watch("matiereIds");

  const toggle = (field: "classeIds" | "matiereIds", id: string, current: string[]) => {
    setValue(field, current.includes(id) ? current.filter((x) => x !== id) : [...current, id]);
  };

  const submit = async (data: FormValues) => {
    setSubmitting(true);
    setServerError(null);
    try {
      await onSubmit(data);
    } catch (err) {
      setServerError(err instanceof Error ? err.message : "Une erreur est survenue.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit(submit)} className="space-y-4 max-w-xl">
      {serverError && (
        <div className="rounded-lg bg-red-50 border border-red-200 text-red-700 text-sm px-3 py-2.5">
          {serverError}
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <Field label="Nom complet" error={errors.fullName?.message}>
          <input className="input" placeholder="Ex: Moussa Diop" {...register("fullName")} />
        </Field>
        <Field label="Matricule" error={errors.matricule?.message}>
          <input className="input" placeholder="Ex: PR-2026-007" {...register("matricule")} />
        </Field>
        <Field label="Email" error={errors.email?.message}>
          <input className="input" type="email" placeholder="prof@protechnica.sn" {...register("email")} />
        </Field>
        <Field label="Téléphone">
          <input className="input" placeholder="+221 77 000 00 00" {...register("phone")} />
        </Field>
        <Field label="Spécialité">
          <input className="input" placeholder="Ex: Génie Logiciel" {...register("specialite")} />
        </Field>
        <Field label="Date d'embauche">
          <input className="input" type="date" {...register("dateEmbauche")} />
        </Field>
        <Field label="Mot de passe temporaire" error={errors.password?.message}>
          <div className="flex gap-2">
            <input className="input flex-1" {...register("password")} />
            <Button type="button" variant="outline" size="icon" onClick={() => setValue("password", generatePassword())}>
              <RefreshCw className="h-3.5 w-3.5" />
            </Button>
          </div>
        </Field>
      </div>

      <div>
        <label className="text-sm font-medium mb-1.5 block">Matières enseignées</label>
        <div className="flex flex-wrap gap-1.5">
          {subjects.map((s) => (
            <button
              type="button"
              key={s.id}
              onClick={() => toggle("matiereIds", s.id, selectedSubjects)}
              className={`rounded-full px-3 py-1 text-xs font-medium border ${
                selectedSubjects.includes(s.id) ? "bg-primary text-white border-primary" : "border-border text-muted-foreground"
              }`}
            >
              {s.nom}
            </button>
          ))}
          {subjects.length === 0 && <p className="text-xs text-muted-foreground">Aucune matière en base.</p>}
        </div>
      </div>

      <div>
        <label className="text-sm font-medium mb-1.5 block">Classes affectées</label>
        <div className="flex flex-wrap gap-1.5">
          {classes.map((c) => (
            <button
              type="button"
              key={c.id}
              onClick={() => toggle("classeIds", c.id, selectedClasses)}
              className={`rounded-full px-3 py-1 text-xs font-medium border ${
                selectedClasses.includes(c.id) ? "bg-primary text-white border-primary" : "border-border text-muted-foreground"
              }`}
            >
              {c.nom}
            </button>
          ))}
        </div>
      </div>

      <Button type="submit" disabled={submitting} className="gap-1.5">
        {submitting ? "Création…" : "Créer le compte professeur"}
      </Button>
    </form>
  );
}

function Field({ label, error, children }: { label: string; error?: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="text-sm font-medium mb-1.5 block">{label}</label>
      {children}
      {error && <p className="text-xs text-red-600 mt-1">{error}</p>}
    </div>
  );
}
