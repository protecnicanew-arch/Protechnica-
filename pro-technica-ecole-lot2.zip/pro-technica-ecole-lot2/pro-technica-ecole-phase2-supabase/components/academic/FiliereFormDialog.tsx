"use client";

import { useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Dialog } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import type { Filiere, FiliereType } from "@/lib/types";

const filiereSchema = z.object({
  nom: z.string().min(2, "Le nom est requis"),
  type: z.enum(["BTS", "Licence", "Master", "Formation professionnelle"]),
  dureeAnnees: z.coerce.number().min(1).max(6),
  description: z.string().optional(),
});
type FiliereFormValues = z.infer<typeof filiereSchema>;

const TYPES: FiliereType[] = ["BTS", "Licence", "Master", "Formation professionnelle"];

export function FiliereFormDialog({
  open,
  onClose,
  onSubmit,
  initial,
}: {
  open: boolean;
  onClose: () => void;
  onSubmit: (data: FiliereFormValues) => void;
  initial?: Filiere;
}) {
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<FiliereFormValues>({ resolver: zodResolver(filiereSchema) });

  useEffect(() => {
    if (open) {
      reset(
        initial
          ? { nom: initial.nom, type: initial.type, dureeAnnees: initial.dureeAnnees, description: initial.description ?? "" }
          : { nom: "", type: "Licence", dureeAnnees: 3, description: "" }
      );
    }
  }, [open, initial, reset]);

  const submit = (data: FiliereFormValues) => {
    onSubmit(data);
    onClose();
  };

  return (
    <Dialog open={open} onClose={onClose} title={initial ? "Modifier la filière" : "Nouvelle filière"}>
      <form onSubmit={handleSubmit(submit)} className="space-y-4">
        <div>
          <label className="text-sm font-medium mb-1.5 block">Nom de la filière</label>
          <input
            className="w-full rounded-lg border border-border bg-background px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-ring"
            placeholder="Ex: Génie Logiciel"
            {...register("nom")}
          />
          {errors.nom && <p className="text-xs text-red-600 mt-1">{errors.nom.message}</p>}
        </div>

        <div>
          <label className="text-sm font-medium mb-1.5 block">Type</label>
          <select
            className="w-full rounded-lg border border-border bg-background px-3 py-2.5 text-sm outline-none"
            {...register("type")}
          >
            {TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
          </select>
        </div>

        <div>
          <label className="text-sm font-medium mb-1.5 block">Durée (années)</label>
          <input
            type="number"
            min={1}
            max={6}
            className="w-full rounded-lg border border-border bg-background px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-ring"
            {...register("dureeAnnees")}
          />
          {errors.dureeAnnees && <p className="text-xs text-red-600 mt-1">{errors.dureeAnnees.message}</p>}
        </div>

        <div>
          <label className="text-sm font-medium mb-1.5 block">Description (optionnel)</label>
          <textarea
            rows={2}
            className="w-full rounded-lg border border-border bg-background px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-ring resize-none"
            {...register("description")}
          />
        </div>

        <div className="flex gap-2 pt-2">
          <Button type="button" variant="outline" className="flex-1" onClick={onClose}>Annuler</Button>
          <Button type="submit" className="flex-1">{initial ? "Enregistrer" : "Créer"}</Button>
        </div>
      </form>
    </Dialog>
  );
}
