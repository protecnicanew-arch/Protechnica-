"use client";

import { useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Dialog } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import type { Classe, Filiere } from "@/lib/types";

const classeSchema = z.object({
  nom: z.string().min(2, "Le nom est requis"),
  filiereId: z.string().min(1, "Choisissez une filière"),
  anneeScolaire: z.string().min(4, "Ex: 2025-2026"),
  effectifMax: z.coerce.number().min(1).max(200),
});
type ClasseFormValues = z.infer<typeof classeSchema>;

export function ClasseFormDialog({
  open,
  onClose,
  onSubmit,
  initial,
  filieres,
}: {
  open: boolean;
  onClose: () => void;
  onSubmit: (data: ClasseFormValues) => void;
  initial?: Classe;
  filieres: Filiere[];
}) {
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<ClasseFormValues>({ resolver: zodResolver(classeSchema) });

  useEffect(() => {
    if (open) {
      reset(
        initial
          ? { nom: initial.nom, filiereId: initial.filiereId, anneeScolaire: initial.anneeScolaire, effectifMax: initial.effectifMax }
          : { nom: "", filiereId: filieres[0]?.id ?? "", anneeScolaire: "2025-2026", effectifMax: 40 }
      );
    }
  }, [open, initial, filieres, reset]);

  const submit = (data: ClasseFormValues) => {
    onSubmit(data);
    onClose();
  };

  return (
    <Dialog open={open} onClose={onClose} title={initial ? "Modifier la classe" : "Nouvelle classe"}>
      <form onSubmit={handleSubmit(submit)} className="space-y-4">
        <div>
          <label className="text-sm font-medium mb-1.5 block">Nom de la classe</label>
          <input
            className="w-full rounded-lg border border-border bg-background px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-ring"
            placeholder="Ex: Licence 2 - Génie Logiciel B"
            {...register("nom")}
          />
          {errors.nom && <p className="text-xs text-red-600 mt-1">{errors.nom.message}</p>}
        </div>

        <div>
          <label className="text-sm font-medium mb-1.5 block">Filière</label>
          <select
            className="w-full rounded-lg border border-border bg-background px-3 py-2.5 text-sm outline-none"
            {...register("filiereId")}
          >
            {filieres.map((f) => <option key={f.id} value={f.id}>{f.nom}</option>)}
          </select>
          {errors.filiereId && <p className="text-xs text-red-600 mt-1">{errors.filiereId.message}</p>}
        </div>

        <div>
          <label className="text-sm font-medium mb-1.5 block">Année scolaire</label>
          <input
            className="w-full rounded-lg border border-border bg-background px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-ring"
            placeholder="2025-2026"
            {...register("anneeScolaire")}
          />
          {errors.anneeScolaire && <p className="text-xs text-red-600 mt-1">{errors.anneeScolaire.message}</p>}
        </div>

        <div>
          <label className="text-sm font-medium mb-1.5 block">Effectif maximum</label>
          <input
            type="number"
            min={1}
            max={200}
            className="w-full rounded-lg border border-border bg-background px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-ring"
            {...register("effectifMax")}
          />
          {errors.effectifMax && <p className="text-xs text-red-600 mt-1">{errors.effectifMax.message}</p>}
        </div>

        <div className="flex gap-2 pt-2">
          <Button type="button" variant="outline" className="flex-1" onClick={onClose}>Annuler</Button>
          <Button type="submit" className="flex-1">{initial ? "Enregistrer" : "Créer"}</Button>
        </div>
      </form>
    </Dialog>
  );
}
