"use client";

import { useMemo, useState } from "react";
import { Save } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useAcademicStore } from "@/lib/store";
import type { Grade } from "@/lib/types";

const TYPES: Grade["type"][] = ["controle", "devoir", "examen"];
const TYPE_LABELS: Record<Grade["type"], string> = { controle: "Contrôle", devoir: "Devoir", examen: "Examen" };

export function GradeEntryForm() {
  const { classes, students, teachers, grades, upsertGrade } = useAcademicStore();
  const [classeId, setClasseId] = useState(classes[0]?.id ?? "");
  const [matiere, setMatiere] = useState("");
  const [type, setType] = useState<Grade["type"]>("controle");
  const [date, setDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [bareme, setBareme] = useState(20);
  const [coefficient, setCoefficient] = useState(1);
  const [notes, setNotes] = useState<Record<string, string>>({});
  const [saved, setSaved] = useState(false);

  const classStudents = useMemo(() => students.filter((s) => s.classeId === classeId), [students, classeId]);

  const matieresDisponibles = useMemo(() => {
    const set = new Set<string>();
    teachers.forEach((t) => t.classesIds.includes(classeId) && t.matieres.forEach((m) => set.add(m)));
    return Array.from(set);
  }, [teachers, classeId]);

  const existingNote = (studentId: string) =>
    grades.find((g) => g.studentId === studentId && g.matiere === matiere && g.type === type && g.date === date)?.note;

  const handleSave = () => {
    if (!matiere) return;
    classStudents.forEach((s) => {
      const raw = notes[s.id] ?? existingNote(s.id)?.toString();
      if (raw === undefined || raw === "") return;
      const note = Number(raw);
      if (Number.isNaN(note)) return;
      upsertGrade({
        studentId: s.id,
        matiere,
        type,
        note,
        bareme,
        coefficient,
        date,
        professeurId: teachers.find((t) => t.matieres.includes(matiere))?.id ?? "",
      });
    });
    setSaved(true);
    setNotes({});
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Saisie des notes</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-6 gap-3 mb-5">
          <select value={classeId} onChange={(e) => setClasseId(e.target.value)} className="col-span-2 rounded-lg border border-border bg-background px-3 py-2 text-sm outline-none">
            {classes.map((c) => <option key={c.id} value={c.id}>{c.nom}</option>)}
          </select>
          <input
            value={matiere}
            onChange={(e) => setMatiere(e.target.value)}
            list="matieres-list"
            placeholder="Matière"
            className="col-span-2 rounded-lg border border-border bg-background px-3 py-2 text-sm outline-none"
          />
          <datalist id="matieres-list">
            {matieresDisponibles.map((m) => <option key={m} value={m} />)}
          </datalist>
          <select value={type} onChange={(e) => setType(e.target.value as Grade["type"])} className="rounded-lg border border-border bg-background px-3 py-2 text-sm outline-none">
            {TYPES.map((t) => <option key={t} value={t}>{TYPE_LABELS[t]}</option>)}
          </select>
          <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="rounded-lg border border-border bg-background px-3 py-2 text-sm outline-none" />
          <input type="number" min={1} value={bareme} onChange={(e) => setBareme(Number(e.target.value))} placeholder="Barème" className="rounded-lg border border-border bg-background px-3 py-2 text-sm outline-none" />
          <input type="number" min={1} value={coefficient} onChange={(e) => setCoefficient(Number(e.target.value))} placeholder="Coefficient" className="rounded-lg border border-border bg-background px-3 py-2 text-sm outline-none" />
        </div>

        {!matiere && (
          <p className="text-sm text-muted-foreground mb-3">Renseignez une matière pour commencer la saisie.</p>
        )}

        <div className="space-y-2 mb-4">
          {classStudents.map((s) => (
            <div key={s.id} className="flex items-center justify-between gap-3 rounded-lg border border-border px-4 py-2.5">
              <div>
                <p className="text-sm font-medium">{s.fullName}</p>
                <p className="text-xs text-muted-foreground">{s.matricule}</p>
              </div>
              <input
                type="number"
                min={0}
                max={bareme}
                step={0.5}
                placeholder={existingNote(s.id)?.toString() ?? `/ ${bareme}`}
                value={notes[s.id] ?? ""}
                onChange={(e) => setNotes((prev) => ({ ...prev, [s.id]: e.target.value }))}
                className="w-24 rounded-lg border border-border bg-background px-3 py-1.5 text-sm text-right outline-none focus:ring-2 focus:ring-ring"
              />
            </div>
          ))}
          {classStudents.length === 0 && (
            <p className="text-sm text-muted-foreground text-center py-6">Aucun étudiant dans cette classe.</p>
          )}
        </div>

        <div className="flex items-center gap-3">
          <Button onClick={handleSave} disabled={!matiere} className="gap-1.5">
            <Save className="h-4 w-4" /> Enregistrer les notes
          </Button>
          {saved && <p className="text-xs text-emerald-600">Notes enregistrées ✓</p>}
        </div>
      </CardContent>
    </Card>
  );
}
