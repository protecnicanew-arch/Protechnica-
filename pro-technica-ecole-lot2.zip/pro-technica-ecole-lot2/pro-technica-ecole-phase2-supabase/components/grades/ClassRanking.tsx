"use client";

import { useMemo, useState } from "react";
import { Trophy } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useAcademicStore } from "@/lib/store";
import { computeClassRanking } from "@/lib/grade-utils";

export function ClassRanking() {
  const { classes, students, grades } = useAcademicStore();
  const [classeId, setClasseId] = useState(classes[0]?.id ?? "");

  const classStudents = useMemo(() => students.filter((s) => s.classeId === classeId), [students, classeId]);
  const ranking = useMemo(() => computeClassRanking(classStudents, grades), [classStudents, grades]);

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>Classement & moyennes</CardTitle>
        <select
          value={classeId}
          onChange={(e) => setClasseId(e.target.value)}
          className="rounded-lg border border-border bg-background px-3 py-2 text-sm outline-none"
        >
          {classes.map((c) => <option key={c.id} value={c.id}>{c.nom}</option>)}
        </select>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          {ranking.map((row) => (
            <div key={row.student.id} className="flex items-center justify-between rounded-lg border border-border px-4 py-3">
              <div className="flex items-center gap-3">
                <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center text-xs font-semibold text-primary shrink-0">
                  {row.rang ?? "—"}
                </div>
                <div>
                  <p className="text-sm font-medium">{row.student.fullName}</p>
                  <p className="text-xs text-muted-foreground">{row.student.matricule}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                {row.rang === 1 && <Trophy className="h-4 w-4 text-amber-500" />}
                <Badge variant={row.moyenne !== null && row.moyenne >= 10 ? "success" : "destructive"}>
                  {row.moyenne !== null ? `${row.moyenne.toFixed(2)}/20` : "Pas encore noté"}
                </Badge>
              </div>
            </div>
          ))}
          {ranking.length === 0 && (
            <p className="text-sm text-muted-foreground text-center py-6">Aucun étudiant dans cette classe.</p>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
