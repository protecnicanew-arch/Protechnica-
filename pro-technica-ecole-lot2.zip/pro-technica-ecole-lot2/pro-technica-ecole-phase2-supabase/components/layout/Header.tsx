"use client";

import { Bell, Search, Moon, Sun, LogOut, GraduationCap, Users } from "lucide-react";
import { useTheme } from "next-themes";
import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { useSession } from "@/lib/auth/use-session";
import { signOut } from "@/lib/auth/auth-service";
import { ROLE_LABELS } from "@/lib/auth/permissions";
import { useAcademicStore } from "@/lib/store";
import {
  listNotifications,
  markAllNotificationsRead,
  subscribeToNotifications,
  type AppNotification,
} from "@/lib/services/notifications.service";

function initials(fullName: string): string {
  return fullName
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((p) => p[0]?.toUpperCase())
    .join("") || "?";
}

export function Header({ title }: { title: string }) {
  const { theme, setTheme } = useTheme();
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  const router = useRouter();
  const { profile } = useSession();
  const { students, teachers } = useAcademicStore();
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [menuOpen, setMenuOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [searchOpen, setSearchOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);
  const searchRef = useRef<HTMLDivElement>(null);

  const searchResults = (() => {
    const q = search.trim().toLowerCase();
    if (q.length < 2) return { students: [], teachers: [] };
    return {
      students: students.filter((s) => s.fullName.toLowerCase().includes(q) || s.matricule.toLowerCase().includes(q)).slice(0, 5),
      teachers: teachers.filter((t) => t.fullName.toLowerCase().includes(q)).slice(0, 5),
    };
  })();

  const unreadCount = notifications.filter((n) => !n.lu).length;

  useEffect(() => {
    if (!profile) return;
    listNotifications(profile.id).then(setNotifications).catch(() => {});
    const channel = subscribeToNotifications(profile.id, (n) => setNotifications((prev) => [n, ...prev]));
    return () => {
      channel.unsubscribe();
    };
  }, [profile]);

  useEffect(() => {
    function onClickOutside(e: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setMenuOpen(false);
        setNotifOpen(false);
      }
      if (searchRef.current && !searchRef.current.contains(e.target as Node)) {
        setSearchOpen(false);
      }
    }
    document.addEventListener("mousedown", onClickOutside);
    return () => document.removeEventListener("mousedown", onClickOutside);
  }, []);

  const handleSignOut = async () => {
    await signOut();
    router.push("/login");
    router.refresh();
  };

  const handleOpenNotifications = async () => {
    setNotifOpen((v) => !v);
    setMenuOpen(false);
    if (profile && unreadCount > 0) {
      await markAllNotificationsRead(profile.id);
      setNotifications((prev) => prev.map((n) => ({ ...n, lu: true })));
    }
  };

  return (
    <header className="sticky top-0 z-30 flex items-center justify-between gap-4 border-b border-border bg-background/80 glass px-4 py-3 lg:px-8"
      style={{ paddingTop: "calc(0.75rem + env(safe-area-inset-top, 0px))" }}
    >
      <div>
        <h1 className="text-lg font-semibold lg:text-xl">{title}</h1>
      </div>

      <div className="hidden md:flex flex-1 max-w-md relative" ref={searchRef}>
        <div className="flex items-center gap-2 rounded-lg border border-border bg-muted/50 px-3 py-2 w-full">
          <Search className="h-4 w-4 text-muted-foreground" />
          <input
            value={search}
            onChange={(e) => { setSearch(e.target.value); setSearchOpen(true); }}
            onFocus={() => setSearchOpen(true)}
            placeholder="Rechercher un étudiant ou un professeur…"
            className="w-full bg-transparent text-sm outline-none placeholder:text-muted-foreground"
          />
        </div>
        {searchOpen && search.trim().length >= 2 && (
          <div className="absolute top-full mt-2 w-full rounded-lg border border-border bg-background shadow-lg z-40 max-h-96 overflow-y-auto">
            {searchResults.students.length === 0 && searchResults.teachers.length === 0 ? (
              <p className="px-4 py-6 text-sm text-muted-foreground text-center">Aucun résultat pour « {search} ».</p>
            ) : (
              <>
                {searchResults.students.map((s) => (
                  <button
                    key={s.id}
                    onClick={() => { router.push(`/dashboard/etudiants/${s.id}`); setSearch(""); setSearchOpen(false); }}
                    className="w-full flex items-center gap-2.5 px-4 py-2.5 text-sm text-left hover:bg-muted/60"
                  >
                    <GraduationCap className="h-4 w-4 text-muted-foreground shrink-0" />
                    <span><span className="font-medium">{s.fullName}</span> <span className="text-xs text-muted-foreground">· {s.matricule}</span></span>
                  </button>
                ))}
                {searchResults.teachers.map((t) => (
                  <button
                    key={t.id}
                    onClick={() => { router.push(`/dashboard/professeurs/${t.id}`); setSearch(""); setSearchOpen(false); }}
                    className="w-full flex items-center gap-2.5 px-4 py-2.5 text-sm text-left hover:bg-muted/60"
                  >
                    <Users className="h-4 w-4 text-muted-foreground shrink-0" />
                    <span className="font-medium">{t.fullName}</span>
                  </button>
                ))}
              </>
            )}
          </div>
        )}
      </div>

      <div className="flex items-center gap-1" ref={menuRef}>
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
          aria-label="Changer de thème"
        >
          {mounted && theme === "dark" ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
        </Button>

        <div className="relative">
          <Button variant="ghost" size="icon" aria-label="Notifications" className="relative" onClick={handleOpenNotifications}>
            <Bell className="h-4 w-4" />
            {unreadCount > 0 && (
              <span className="absolute right-1.5 top-1.5 h-1.5 w-1.5 rounded-full bg-primary" />
            )}
          </Button>
          {notifOpen && (
            <div className="absolute right-0 mt-2 w-80 max-h-96 overflow-y-auto rounded-lg border border-border bg-background shadow-lg z-40">
              <div className="px-4 py-2.5 border-b border-border text-sm font-medium">Notifications</div>
              {notifications.length === 0 ? (
                <p className="px-4 py-6 text-sm text-muted-foreground text-center">Aucune notification.</p>
              ) : (
                notifications.map((n) => (
                  <div key={n.id} className="px-4 py-3 border-b border-border last:border-0 text-sm">
                    <p className="font-medium">{n.titre}</p>
                    <p className="text-muted-foreground text-xs mt-0.5">{n.message}</p>
                  </div>
                ))
              )}
            </div>
          )}
        </div>

        <div className="relative">
          <button
            onClick={() => {
              setMenuOpen((v) => !v);
              setNotifOpen(false);
            }}
            className="ml-2 h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center text-xs font-semibold text-primary"
            aria-label="Menu utilisateur"
          >
            {profile ? initials(profile.full_name) : "…"}
          </button>
          {menuOpen && (
            <div className="absolute right-0 mt-2 w-56 rounded-lg border border-border bg-background shadow-lg z-40">
              {profile && (
                <div className="px-4 py-3 border-b border-border">
                  <p className="text-sm font-medium truncate">{profile.full_name}</p>
                  <p className="text-xs text-muted-foreground truncate">{profile.email}</p>
                  <p className="text-xs text-primary mt-1">{ROLE_LABELS[profile.role]}</p>
                </div>
              )}
              <button
                onClick={handleSignOut}
                className="w-full flex items-center gap-2 px-4 py-2.5 text-sm text-red-600 hover:bg-red-50"
              >
                <LogOut className="h-4 w-4" /> Se déconnecter
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
