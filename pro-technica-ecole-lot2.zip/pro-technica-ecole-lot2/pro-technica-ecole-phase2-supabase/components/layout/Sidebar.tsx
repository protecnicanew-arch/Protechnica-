"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { motion } from "framer-motion";
import { GraduationCap } from "lucide-react";
import { sidebarNav } from "@/lib/navigation";
import { cn } from "@/lib/utils";
import { useSession } from "@/lib/auth/use-session";
import { canAny } from "@/lib/auth/permissions";

export function Sidebar() {
  const pathname = usePathname();
  const { profile } = useSession();
  // Tant que le rôle n'est pas encore chargé, on n'affiche que les items
  // toujours visibles (pas de flash du menu complet avant filtrage).
  const visibleNav = sidebarNav.filter((item) => !item.resource || (profile && canAny(profile.role, item.resource)));

  return (
    <aside className="hidden lg:flex h-screen w-64 flex-col border-r border-border bg-secondary text-secondary-foreground sticky top-0">
      <div className="flex items-center gap-2 px-6 py-6 border-b border-white/10">
        <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary">
          <GraduationCap className="h-5 w-5 text-white" />
        </div>
        <div>
          <p className="text-sm font-semibold leading-tight">PRO TECHNICA</p>
          <p className="text-[11px] uppercase tracking-wider text-white/50 leading-tight">École</p>
        </div>
      </div>

      <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-1">
        {visibleNav.map((item) => {
          const active = pathname === item.href;
          const Icon = item.icon;
          return (
            <Link key={item.href} href={item.href} className="relative block">
              {active && (
                <motion.div
                  layoutId="sidebar-active"
                  className="absolute inset-0 rounded-lg bg-primary"
                  transition={{ type: "spring", stiffness: 400, damping: 32 }}
                />
              )}
              <span
                className={cn(
                  "relative z-10 flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors",
                  active ? "text-white" : "text-white/70 hover:text-white hover:bg-white/5"
                )}
              >
                <Icon className="h-4 w-4 shrink-0" />
                {item.label}
              </span>
            </Link>
          );
        })}
      </nav>

      <div className="px-4 py-4 border-t border-white/10 text-[11px] text-white/40">
        © 2026 PRO TECHNICA ÉCOLE
      </div>
    </aside>
  );
}
