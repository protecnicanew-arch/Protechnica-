"use client";

import { useMemo, useState } from "react";
import { Check } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useAcademicStore } from "@/lib/store";
import { ATTENDANCE_STATUSES, attendanceLabel } from "./AttendanceBadge";
import type { AttendanceStatus } from "@/lib/types";

export function AttendanceSessionForm() {
  const { classes, students, attendance, markAttendance } = useAcademicStore();
  const [classeId, setClasseId] = useState(classes[0]?.id ?? "");
  const [date, setDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [saved, setSaved] = useState(false);

  const classStudents = useMemo(
    () => students.filter((s) => s.classeId === classeId),
    [students, classeId]
  );

  const statusFor = (studentId: string): AttendanceStatus | undefined =>
    attendance.find((a) => a.personId === studentId && a.personType === "etudiant" && a.date === date)?.status;

  const setStatus = (studentId: string, status: AttendanceStatus) => {
    markAttendance(studentId, "etudiant", date, status, classeId);
    setSaved(false);
  };

  const markAllPresent = () => {
    classStudents.forEach((s) => markAttendance(s.id, "etudiant", date, "present", classeId));
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <Card>
      <CardHeader className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <CardTitle>Prise des présences</CardTitle>
        <div className="flex flex-wrap gap-2">
          <select
            value={classeId}
            onChange={(e) => setClasseId(e.target.value)}
            className="rounded-lg border border-border bg-background px-3 py-2 text-sm outline-none"
          >
            {classes.map((c) => <option key={c.id} value={c.id}>{c.nom}</option>)}
          </select>
          <input
            type="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            className="rounded-lg border border-border bg-background px-3 py-2 text-sm outline-none"
          />
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex justify-end mb-3">
          <Button size="sm" variant="outline" onClick={markAllPresent} className="gap-1.5">
            <Check className="h-3.5 w-3.5" /> Tout marquer présent
          </Button>
        </div>

        <div className="space-y-2">
          {classStudents.map((s) => {
            const current = statusFor(s.id);
            return (
              <div key={s.id} className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 rounded-lg border border-border px-4 py-3">
                <div>
                  <p className="text-sm font-medium">{s.fullName}</p>
                  <p className="text-xs text-muted-foreground">{s.matricule}</p>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {ATTENDANCE_STATUSES.map((status) => (
                    <button
                      key={status}
                      onClick={() => setStatus(s.id, status)}
                      className={`rounded-full px-3 py-1 text-xs font-medium border transition-colors ${
                        current === status
                          ? "bg-primary text-primary-foreground border-primary"
                          : "border-border text-muted-foreground hover:border-primary/50"
                      }`}
                    >
                      {attendanceLabel(status)}
                    </button>
                  ))}
                </div>
              </div>
            );
          })}
          {classStudents.length === 0 && (
            <p className="text-sm text-muted-foreground text-center py-6">Aucun étudiant dans cette classe.</p>
          )}
        </div>

        {saved && <p className="text-xs text-emerald-600 mt-3">Présences enregistrées ✓</p>}
      </CardContent>
    </Card>
  );
}
