import { Badge } from "@/components/ui/badge";
import type { AttendanceStatus } from "@/lib/types";

const map: Record<AttendanceStatus, { label: string; variant: any }> = {
  present: { label: "Présent", variant: "success" },
  absent: { label: "Absent", variant: "destructive" },
  retard: { label: "Retard", variant: "warning" },
  justifie: { label: "Justifié", variant: "secondary" },
};

export function AttendanceBadge({ status }: { status: AttendanceStatus }) {
  const { label, variant } = map[status];
  return <Badge variant={variant}>{label}</Badge>;
}

export const ATTENDANCE_STATUSES: AttendanceStatus[] = ["present", "absent", "retard", "justifie"];
export const attendanceLabel = (s: AttendanceStatus) => map[s].label;
