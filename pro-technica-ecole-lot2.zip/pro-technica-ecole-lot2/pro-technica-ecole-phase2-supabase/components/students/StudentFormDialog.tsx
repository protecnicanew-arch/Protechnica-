"use client";

import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import type { Classe, Filiere } from "@/lib/types";

function generatePassword() {
  return `PT-${Math.random().toString(36).slice(2, 6)}${Math.floor(Math.random() * 100)}!`;
}

const schema = z.object({
  fullName: z.string().min(2, "Nom complet requis"),
  email: z.string().email("Email invalide"),
  phone: z.string().optional(),
  matricule: z.string().min(2, "Matricule requis"),
  classeId: z.string().min(1, "Choisissez une classe"),
  programId: z.string().min(1, "Choisissez une filière"),
  dateNaissance: z.string().optional(),
  password: z.string().min(6, "6 caractères minimum"),
});
type FormValues = z.infer<typeof schema>;

export function StudentFormDialog({
  classes,
  filieres,
  onSubmit,
}: {
  classes: Classe[];
  filieres: Filiere[];
  onSubmit: (data: FormValues) => Promise<void>;
}) {
  const [submitting, setSubmitting] = useState(false);
  const [serverError, setServerError] = useState<string | null>(null);
  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors },
  } = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: { password: generatePassword(), classeId: classes[0]?.id ?? "", programId: filieres[0]?.id ?? "" },
  });

  const submit = async (data: FormValues) => {
    setSubmitting(true);
    setServerError(null);
    try {
      await onSubmit(data);
    } catch (err) {
      setServerError(err instanceof Error ? err.message : "Une erreur est survenue.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit(submit)} className="space-y-4 max-w-xl">
      {serverError && (
        <div className="rounded-lg bg-red-50 border border-red-200 text-red-700 text-sm px-3 py-2.5">
          {serverError}
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <Field label="Nom complet" error={errors.fullName?.message}>
          <input className="input" placeholder="Ex: Awa Ndiaye" {...register("fullName")} />
        </Field>
        <Field label="Matricule" error={errors.matricule?.message}>
          <input className="input" placeholder="Ex: ET-2026-014" {...register("matricule")} />
        </Field>
        <Field label="Email" error={errors.email?.message}>
          <input className="input" type="email" placeholder="etudiant@protechnica.sn" {...register("email")} />
        </Field>
        <Field label="Téléphone">
          <input className="input" placeholder="+221 77 000 00 00" {...register("phone")} />
        </Field>
        <Field label="Classe" error={errors.classeId?.message}>
          <select className="input" {...register("classeId")}>
            {classes.map((c) => (
              <option key={c.id} value={c.id}>{c.nom}</option>
            ))}
          </select>
        </Field>
        <Field label="Filière" error={errors.programId?.message}>
          <select className="input" {...register("programId")}>
            {filieres.map((f) => (
              <option key={f.id} value={f.id}>{f.nom}</option>
            ))}
          </select>
        </Field>
        <Field label="Date de naissance">
          <input className="input" type="date" {...register("dateNaissance")} />
        </Field>
        <Field label="Mot de passe temporaire" error={errors.password?.message}>
          <div className="flex gap-2">
            <input className="input flex-1" {...register("password")} />
            <Button type="button" variant="outline" size="icon" onClick={() => setValue("password", generatePassword())}>
              <RefreshCw className="h-3.5 w-3.5" />
            </Button>
          </div>
        </Field>
      </div>

      <p className="text-xs text-muted-foreground">
        L'étudiant devra changer ce mot de passe à sa première connexion (ou utiliser « Mot de passe oublié »).
      </p>

      <Button type="submit" disabled={submitting} className="gap-1.5">
        {submitting ? "Création…" : "Créer le compte étudiant"}
      </Button>
    </form>
  );
}

function Field({ label, error, children }: { label: string; error?: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="text-sm font-medium mb-1.5 block">{label}</label>
      {children}
      {error && <p className="text-xs text-red-600 mt-1">{error}</p>}
    </div>
  );
}
