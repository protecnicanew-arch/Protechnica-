"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import {
  useReactTable,
  getCoreRowModel,
  getFilteredRowModel,
  getSortedRowModel,
  getPaginationRowModel,
  flexRender,
  createColumnHelper,
} from "@tanstack/react-table";
import { Search, ChevronLeft, ChevronRight, Eye } from "lucide-react";
import type { Student, Classe } from "@/lib/types";
import { StudentStatusBadge } from "./StatusBadges";
import { formatCFA } from "@/lib/utils";
import { Button } from "@/components/ui/button";

const columnHelper = createColumnHelper<Student>();

export function StudentsTable({
  students,
  classes,
}: {
  students: Student[];
  classes: Classe[];
}) {
  const [search, setSearch] = useState("");
  const [classeFilter, setClasseFilter] = useState<string>("tous");
  const [statutFilter, setStatutFilter] = useState<string>("tous");

  const classeName = (id: string) => classes.find((c) => c.id === id)?.nom ?? "—";

  const filtered = useMemo(() => {
    return students.filter((s) => {
      const matchSearch =
        search.trim() === "" ||
        s.fullName.toLowerCase().includes(search.toLowerCase()) ||
        s.matricule.toLowerCase().includes(search.toLowerCase()) ||
        s.email.toLowerCase().includes(search.toLowerCase());
      const matchClasse = classeFilter === "tous" || s.classeId === classeFilter;
      const matchStatut = statutFilter === "tous" || s.statut === statutFilter;
      return matchSearch && matchClasse && matchStatut;
    });
  }, [students, search, classeFilter, statutFilter]);

  const columns = useMemo(
    () => [
      columnHelper.accessor("matricule", { header: "Matricule" }),
      columnHelper.accessor("fullName", {
        header: "Nom complet",
        cell: (info) => (
          <div className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center text-xs font-semibold text-primary shrink-0">
              {info.getValue().split(" ").map((n) => n[0]).join("").slice(0, 2)}
            </div>
            <span className="font-medium">{info.getValue()}</span>
          </div>
        ),
      }),
      columnHelper.accessor("classeId", {
        header: "Classe",
        cell: (info) => classeName(info.getValue()),
      }),
      columnHelper.accessor("soldeRestant", {
        header: "Solde restant",
        cell: (info) => (
          <span className={info.getValue() > 0 ? "text-red-600 font-medium" : "text-emerald-600"}>
            {formatCFA(info.getValue())}
          </span>
        ),
      }),
      columnHelper.accessor("statut", {
        header: "Statut",
        cell: (info) => <StudentStatusBadge statut={info.getValue()} />,
      }),
      columnHelper.display({
        id: "actions",
        header: "",
        cell: (info) => (
          <Link href={`/dashboard/etudiants/${info.row.original.id}`}>
            <Button variant="ghost" size="sm" className="gap-1.5">
              <Eye className="h-3.5 w-3.5" /> Voir
            </Button>
          </Link>
        ),
      }),
    ],
    [classes]
  );

  const table = useReactTable({
    data: filtered,
    columns,
    getCoreRowModel: getCoreRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    initialState: { pagination: { pageSize: 8 } },
  });

  return (
    <div>
      <div className="flex flex-col sm:flex-row gap-3 mb-4">
        <div className="flex items-center gap-2 rounded-lg border border-border bg-background px-3 py-2 flex-1">
          <Search className="h-4 w-4 text-muted-foreground shrink-0" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Rechercher par nom, matricule, email…"
            className="w-full bg-transparent text-sm outline-none placeholder:text-muted-foreground"
          />
        </div>

        <select
          value={classeFilter}
          onChange={(e) => setClasseFilter(e.target.value)}
          className="rounded-lg border border-border bg-background px-3 py-2 text-sm outline-none"
        >
          <option value="tous">Toutes les classes</option>
          {classes.map((c) => (
            <option key={c.id} value={c.id}>{c.nom}</option>
          ))}
        </select>

        <select
          value={statutFilter}
          onChange={(e) => setStatutFilter(e.target.value)}
          className="rounded-lg border border-border bg-background px-3 py-2 text-sm outline-none"
        >
          <option value="tous">Tous les statuts</option>
          <option value="actif">Actif</option>
          <option value="suspendu">Suspendu</option>
          <option value="diplome">Diplômé</option>
          <option value="abandon">Abandon</option>
        </select>
      </div>

      <div className="overflow-x-auto rounded-xl border border-border bg-card">
        <table className="w-full text-sm">
          <thead>
            {table.getHeaderGroups().map((hg) => (
              <tr key={hg.id} className="border-b border-border">
                {hg.headers.map((header) => (
                  <th key={header.id} className="text-left font-medium text-muted-foreground px-4 py-3 whitespace-nowrap">
                    {flexRender(header.column.columnDef.header, header.getContext())}
                  </th>
                ))}
              </tr>
            ))}
          </thead>
          <tbody>
            {table.getRowModel().rows.map((row) => (
              <tr key={row.id} className="border-b border-border last:border-0 hover:bg-muted/40 transition-colors">
                {row.getVisibleCells().map((cell) => (
                  <td key={cell.id} className="px-4 py-3 whitespace-nowrap">
                    {flexRender(cell.column.columnDef.cell, cell.getContext())}
                  </td>
                ))}
              </tr>
            ))}
            {table.getRowModel().rows.length === 0 && (
              <tr>
                <td colSpan={columns.length} className="text-center py-8 text-muted-foreground">
                  Aucun étudiant ne correspond à votre recherche.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <div className="flex items-center justify-between mt-4">
        <p className="text-xs text-muted-foreground">
          {filtered.length} étudiant{filtered.length > 1 ? "s" : ""} trouvé{filtered.length > 1 ? "s" : ""}
        </p>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="icon" onClick={() => table.previousPage()} disabled={!table.getCanPreviousPage()}>
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <span className="text-xs text-muted-foreground">
            Page {table.getState().pagination.pageIndex + 1} / {table.getPageCount() || 1}
          </span>
          <Button variant="outline" size="icon" onClick={() => table.nextPage()} disabled={!table.getCanNextPage()}>
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}
