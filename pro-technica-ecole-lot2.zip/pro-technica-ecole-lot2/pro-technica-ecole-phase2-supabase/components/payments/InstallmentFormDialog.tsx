"use client";

import { useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Dialog } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import type { Payment } from "@/lib/types";
import { formatCFA } from "@/lib/utils";

const schema = z.object({
  montant: z.coerce.number().min(1, "Montant requis"),
  modePaiement: z.enum(["especes", "virement", "mobile_money", "cheque", "carte"]),
});
type FormValues = z.infer<typeof schema>;

export function InstallmentFormDialog({
  open,
  onClose,
  onSubmit,
  payment,
}: {
  open: boolean;
  onClose: () => void;
  onSubmit: (data: FormValues) => void;
  payment: Payment | null;
}) {
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<FormValues>({ resolver: zodResolver(schema) });

  const reste = payment ? payment.montantDu - payment.montantPaye : 0;

  useEffect(() => {
    if (open && payment) reset({ montant: Math.max(reste, 0), modePaiement: "especes" });
  }, [open, payment, reste, reset]);

  if (!payment) return null;

  const submit = (data: FormValues) => {
    onSubmit(data);
    onClose();
  };

  return (
    <Dialog open={open} onClose={onClose} title={`Encaisser — ${payment.libelle}`}>
      <form onSubmit={handleSubmit(submit)} className="space-y-4">
        <p className="text-sm text-muted-foreground">
          Restant dû : <span className="font-semibold text-foreground">{formatCFA(reste)}</span>
        </p>

        <div>
          <label className="text-sm font-medium mb-1.5 block">Montant encaissé (FCFA)</label>
          <input type="number" className="input" {...register("montant")} />
          {errors.montant && <p className="text-xs text-red-600 mt-1">{errors.montant.message}</p>}
        </div>

        <div>
          <label className="text-sm font-medium mb-1.5 block">Mode de paiement</label>
          <select className="input" {...register("modePaiement")}>
            <option value="especes">Espèces</option>
            <option value="virement">Virement</option>
            <option value="mobile_money">Mobile Money</option>
            <option value="cheque">Chèque</option>
            <option value="carte">Carte</option>
          </select>
        </div>

        <div className="flex gap-2 pt-2">
          <Button type="button" variant="outline" className="flex-1" onClick={onClose}>Annuler</Button>
          <Button type="submit" className="flex-1">Encaisser</Button>
        </div>
      </form>
    </Dialog>
  );
}
