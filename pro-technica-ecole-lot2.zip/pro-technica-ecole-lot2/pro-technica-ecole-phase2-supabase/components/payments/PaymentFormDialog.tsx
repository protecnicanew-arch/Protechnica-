"use client";

import { useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Dialog } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import type { Student } from "@/lib/types";

const schema = z.object({
  studentId: z.string().min(1, "Choisissez un étudiant"),
  libelle: z.string().min(2, "Libellé requis"),
  type: z.enum(["inscription", "scolarite", "examen", "autre"]),
  montantDu: z.coerce.number().min(1, "Montant requis"),
  dateEcheance: z.string().optional(),
});
type FormValues = z.infer<typeof schema>;

export function PaymentFormDialog({
  open,
  onClose,
  onSubmit,
  students,
}: {
  open: boolean;
  onClose: () => void;
  onSubmit: (data: FormValues) => void;
  students: Student[];
}) {
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<FormValues>({ resolver: zodResolver(schema) });

  useEffect(() => {
    if (open) reset({ studentId: students[0]?.id ?? "", libelle: "", type: "scolarite", montantDu: 0, dateEcheance: "" });
  }, [open, students, reset]);

  const submit = (data: FormValues) => {
    onSubmit(data);
    onClose();
  };

  return (
    <Dialog open={open} onClose={onClose} title="Nouveau paiement à facturer">
      <form onSubmit={handleSubmit(submit)} className="space-y-4">
        <div>
          <label className="text-sm font-medium mb-1.5 block">Étudiant</label>
          <select className="input" {...register("studentId")}>
            {students.map((s) => (
              <option key={s.id} value={s.id}>{s.fullName} — {s.matricule}</option>
            ))}
          </select>
          {errors.studentId && <p className="text-xs text-red-600 mt-1">{errors.studentId.message}</p>}
        </div>

        <div>
          <label className="text-sm font-medium mb-1.5 block">Libellé</label>
          <input className="input" placeholder="Ex: Scolarité — Trimestre 1" {...register("libelle")} />
          {errors.libelle && <p className="text-xs text-red-600 mt-1">{errors.libelle.message}</p>}
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="text-sm font-medium mb-1.5 block">Type</label>
            <select className="input" {...register("type")}>
              <option value="inscription">Inscription</option>
              <option value="scolarite">Scolarité</option>
              <option value="examen">Examen</option>
              <option value="autre">Autre</option>
            </select>
          </div>
          <div>
            <label className="text-sm font-medium mb-1.5 block">Montant dû (FCFA)</label>
            <input type="number" className="input" {...register("montantDu")} />
            {errors.montantDu && <p className="text-xs text-red-600 mt-1">{errors.montantDu.message}</p>}
          </div>
        </div>

        <div>
          <label className="text-sm font-medium mb-1.5 block">Date d'échéance</label>
          <input type="date" className="input" {...register("dateEcheance")} />
        </div>

        <div className="flex gap-2 pt-2">
          <Button type="button" variant="outline" className="flex-1" onClick={onClose}>Annuler</Button>
          <Button type="submit" className="flex-1">Créer</Button>
        </div>
      </form>
    </Dialog>
  );
}
