import { createServerClient } from "@supabase/ssr";
import { cookies } from "next/headers";
import type { SupabaseClient } from "@supabase/supabase-js";
import type { Database } from "./database.types";

/**
 * Client Supabase pour les Server Components, Route Handlers et Server Actions.
 * Lit/écrit la session via les cookies Next.js (SSR-safe).
 *
 * Le type de retour est forcé explicitement en SupabaseClient<Database> :
 * certaines combinaisons de versions entre @supabase/ssr et @supabase/supabase-js
 * cassent l'inférence automatique du générique (tous les .insert()/.update()
 * deviennent typés "never"). Ce cast neutralise ce problème quelle que soit
 * la version réellement installée par le build.
 */
export async function createClient(): Promise<SupabaseClient<Database>> {
  const cookieStore = await cookies();

  return createServerClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll() {
          return cookieStore.getAll();
        },
        setAll(cookiesToSet) {
          try {
            cookiesToSet.forEach(({ name, value, options }) =>
              cookieStore.set(name, value, options)
            );
          } catch {
            // setAll appelé depuis un Server Component : ignoré, le middleware
            // se charge du rafraîchissement de session sur la requête suivante.
          }
        },
      },
    }
  ) as unknown as SupabaseClient<Database>;
}

/**
 * Client "admin" avec la clé service_role — réservé aux Route Handlers serveur
 * qui doivent contourner la RLS de façon contrôlée (ex: webhooks, tâches cron,
 * scripts d'import en masse). NE JAMAIS exposer côté client.
 */
export async function createAdminClient(): Promise<SupabaseClient<Database>> {
  const { createClient: createSupabaseClient } = await import("@supabase/supabase-js");
  return createSupabaseClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    { auth: { autoRefreshToken: false, persistSession: false } }
  ) as unknown as SupabaseClient<Database>;
}
