"use client";

import { createBrowserClient } from "@supabase/ssr";
import type { SupabaseClient } from "@supabase/supabase-js";
import type { Database } from "./database.types";

/**
 * Client Supabase pour les Client Components ("use client").
 * À utiliser dans les composants interactifs (formulaires, tableaux, temps réel côté client, etc.).
 *
 * Le type de retour est forcé explicitement en SupabaseClient<Database> :
 * certaines combinaisons de versions entre @supabase/ssr et @supabase/supabase-js
 * cassent l'inférence automatique du générique (tous les .insert()/.update()
 * deviennent typés "never"). Ce cast neutralise ce problème quelle que soit
 * la version réellement installée par le build.
 */
export function createClient(): SupabaseClient<Database> {
  return createBrowserClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  ) as unknown as SupabaseClient<Database>;
}
