import type {
  Filiere,
  Classe,
  Student,
  Teacher,
  Payment,
  DashboardStats,
  ActivityLogEntry,
  Actualite,
  Grade,
  ScheduleSlot,
} from "./types";

// ============================================================
// MOCK DATA — remplacé en phase 2 par des requêtes Supabase.
// Chaque fonction get* ci-dessous simule un appel réseau async
// pour que les composants n'aient rien à changer plus tard.
// ============================================================

export const mockFilieres: Filiere[] = [
  { id: "f1", nom: "Génie Logiciel", type: "Licence", dureeAnnees: 3 },
  { id: "f2", nom: "Réseaux & Télécoms", type: "BTS", dureeAnnees: 2 },
  { id: "f3", nom: "Management IT", type: "Master", dureeAnnees: 2 },
  { id: "f4", nom: "Maintenance Auto", type: "Formation professionnelle", dureeAnnees: 1 },
];

export const mockClasses: Classe[] = [
  { id: "c1", nom: "Licence 1 - Génie Logiciel A", filiereId: "f1", anneeScolaire: "2025-2026", effectifMax: 40 },
  { id: "c2", nom: "BTS 2 - Réseaux", filiereId: "f2", anneeScolaire: "2025-2026", effectifMax: 35 },
  { id: "c3", nom: "Master 1 - Management IT", filiereId: "f3", anneeScolaire: "2025-2026", effectifMax: 25 },
];

export const mockStudents: Student[] = [
  {
    id: "s1", matricule: "PT-2026-0142", fullName: "Awa Ndiaye", email: "awa.ndiaye@protechnica.sn",
    phone: "77 123 45 67", classeId: "c1", filiereId: "f1", dateNaissance: "2003-04-12",
    dateInscription: "2025-09-01", statut: "actif", soldeRestant: 75000,
  },
  {
    id: "s2", matricule: "PT-2026-0143", fullName: "Moussa Diop", email: "moussa.diop@protechnica.sn",
    phone: "78 234 56 78", classeId: "c2", filiereId: "f2", dateNaissance: "2002-11-03",
    dateInscription: "2025-09-01", statut: "actif", soldeRestant: 0,
  },
  {
    id: "s3", matricule: "PT-2026-0144", fullName: "Fatou Sow", email: "fatou.sow@protechnica.sn",
    phone: "70 345 67 89", classeId: "c3", filiereId: "f3", dateNaissance: "2001-07-22",
    dateInscription: "2025-09-02", statut: "actif", soldeRestant: 150000,
  },
  {
    id: "s4", matricule: "PT-2026-0145", fullName: "Ibrahima Fall", email: "ibrahima.fall@protechnica.sn",
    phone: "76 456 78 90", classeId: "c1", filiereId: "f1", dateNaissance: "2003-01-15",
    dateInscription: "2025-09-03", statut: "suspendu", soldeRestant: 220000,
  },
];

export const mockTeachers: Teacher[] = [
  { id: "t1", fullName: "Dr. Cheikh Ba", email: "cheikh.ba@protechnica.sn", phone: "77 555 11 22", matieres: ["Algorithmique", "Bases de données"], classesIds: ["c1"], dateEmbauche: "2020-09-01" },
  { id: "t2", fullName: "Mme Aïda Diallo", email: "aida.diallo@protechnica.sn", phone: "78 555 22 33", matieres: ["Réseaux", "Sécurité"], classesIds: ["c2"], dateEmbauche: "2021-01-15" },
];

export const mockPayments: Payment[] = [
  { id: "p1", studentId: "s1", libelle: "Scolarité - Tranche 2", montantDu: 200000, montantPaye: 125000, date: "2026-09-10", status: "partiel" },
  { id: "p2", studentId: "s2", libelle: "Scolarité - Tranche 1", montantDu: 200000, montantPaye: 200000, date: "2026-09-05", status: "paye" },
  { id: "p3", studentId: "s4", libelle: "Frais d'inscription", montantDu: 220000, montantPaye: 0, date: "2026-09-01", status: "en_retard" },
];

export const mockActivityLog: ActivityLogEntry[] = [
  { id: "a1", userId: "u1", userName: "Admin Système", action: "a ajouté un nouvel étudiant (Awa Ndiaye)", date: "2026-09-27T08:15:00Z" },
  { id: "a2", userId: "u2", userName: "Mme Aïda Diallo", action: "a saisi les présences de BTS 2 - Réseaux", date: "2026-09-27T07:40:00Z" },
  { id: "a3", userId: "u3", userName: "Comptabilité", action: "a validé un paiement de Moussa Diop", date: "2026-09-26T16:05:00Z" },
];

export const mockActualites: Actualite[] = [
  { id: "n1", titre: "Rentrée académique 2025-2026", contenu: "La rentrée officielle aura lieu le 1er octobre.", auteurId: "u1", date: "2026-09-20", type: "annonce" },
  { id: "n2", titre: "Journée portes ouvertes", contenu: "Venez découvrir nos filières le 15 octobre.", auteurId: "u1", date: "2026-09-22", type: "evenement" },
];

export const mockGrades: Grade[] = [
  { id: "g1", studentId: "s1", matiere: "Algorithmique", type: "controle", note: 14, bareme: 20, coefficient: 2, date: "2026-09-15", professeurId: "t1" },
  { id: "g2", studentId: "s1", matiere: "Bases de données", type: "devoir", note: 16.5, bareme: 20, coefficient: 1, date: "2026-09-20", professeurId: "t1" },
  { id: "g3", studentId: "s1", matiere: "Anglais", type: "examen", note: 12, bareme: 20, coefficient: 1, date: "2026-09-25", professeurId: "t2" },
  { id: "g4", studentId: "s2", matiere: "Réseaux", type: "controle", note: 15, bareme: 20, coefficient: 2, date: "2026-09-14", professeurId: "t2" },
  { id: "g5", studentId: "s2", matiere: "Sécurité", type: "devoir", note: 13, bareme: 20, coefficient: 1, date: "2026-09-19", professeurId: "t2" },
];

export const mockSchedule: ScheduleSlot[] = [
  { id: "sc1", teacherId: "t1", classeId: "c1", matiere: "Algorithmique", jour: "Lundi", heureDebut: "08:00", heureFin: "10:00", salle: "A101" },
  { id: "sc2", teacherId: "t1", classeId: "c1", matiere: "Bases de données", jour: "Mercredi", heureDebut: "10:15", heureFin: "12:15", salle: "A102" },
  { id: "sc3", teacherId: "t2", classeId: "c2", matiere: "Réseaux", jour: "Mardi", heureDebut: "08:00", heureFin: "10:00", salle: "B201" },
  { id: "sc4", teacherId: "t2", classeId: "c2", matiere: "Sécurité", jour: "Jeudi", heureDebut: "14:00", heureFin: "16:00", salle: "B202" },
];

export const mockDashboardStats: DashboardStats = {
  revenusMois: 12450000,
  revenusMoisPrecedent: 10800000,
  etudiantsInscrits: 486,
  etudiantsMoisPrecedent: 452,
  professeursActifs: 34,
  tauxPresenceMoyen: 91.4,
};

export const mockRevenueSeries = [
  { mois: "Avr", revenus: 8200000 },
  { mois: "Mai", revenus: 9100000 },
  { mois: "Juin", revenus: 7800000 },
  { mois: "Juil", revenus: 6500000 },
  { mois: "Août", revenus: 9900000 },
  { mois: "Sept", revenus: 12450000 },
];

export const mockEnrollmentByFiliere = [
  { filiere: "Génie Logiciel", etudiants: 168 },
  { filiere: "Réseaux & Télécoms", etudiants: 132 },
  { filiere: "Management IT", etudiants: 98 },
  { filiere: "Maintenance Auto", etudiants: 88 },
];

// Simule une latence réseau, comme un futur appel Supabase.
const simulateFetch = <T,>(data: T, ms = 250): Promise<T> =>
  new Promise((resolve) => setTimeout(() => resolve(data), ms));

export const getDashboardStats = () => simulateFetch(mockDashboardStats);
export const getRevenueSeries = () => simulateFetch(mockRevenueSeries);
export const getEnrollmentByFiliere = () => simulateFetch(mockEnrollmentByFiliere);
export const getStudents = () => simulateFetch(mockStudents);
export const getTeachers = () => simulateFetch(mockTeachers);
export const getPayments = () => simulateFetch(mockPayments);
export const getActivityLog = () => simulateFetch(mockActivityLog);
export const getActualites = () => simulateFetch(mockActualites);
export const getClasses = () => simulateFetch(mockClasses);
export const getFilieres = () => simulateFetch(mockFilieres);

// ---- Lookups utilisés par le module Étudiants ----
export const getStudentById = (id: string) =>
  simulateFetch(mockStudents.find((s) => s.id === id) ?? null);

export const getPaymentsByStudent = (studentId: string) =>
  simulateFetch(mockPayments.filter((p) => p.studentId === studentId));

export const getGradesByStudent = (studentId: string) =>
  simulateFetch(mockGrades.filter((g) => g.studentId === studentId));

export const getClasseById = (id: string) =>
  mockClasses.find((c) => c.id === id) ?? null;

export const getFiliereById = (id: string) =>
  mockFilieres.find((f) => f.id === id) ?? null;

// ---- Lookups utilisés par le module Professeurs ----
export const getTeacherById = (id: string) =>
  simulateFetch(mockTeachers.find((t) => t.id === id) ?? null);

export const getScheduleByTeacher = (teacherId: string) =>
  simulateFetch(mockSchedule.filter((s) => s.teacherId === teacherId));

export const getStudentsByClasse = (classeId: string) =>
  mockStudents.filter((s) => s.classeId === classeId);
