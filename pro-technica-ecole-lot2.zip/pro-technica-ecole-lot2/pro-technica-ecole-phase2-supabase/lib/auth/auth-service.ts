"use client";

import { createClient } from "@/lib/supabase/client";
import type { UserRole } from "./permissions";

export interface AuthResult<T = undefined> {
  success: boolean;
  error?: string;
  data?: T;
}

/**
 * Connexion par email / mot de passe.
 */
export async function signIn(email: string, password: string): Promise<AuthResult> {
  const supabase = createClient();
  const { error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) return { success: false, error: translateAuthError(error.message) };
  return { success: true };
}

/**
 * Déconnexion — invalide la session côté serveur et côté client.
 */
export async function signOut(): Promise<AuthResult> {
  const supabase = createClient();
  const { error } = await supabase.auth.signOut();
  if (error) return { success: false, error: error.message };
  return { success: true };
}

/**
 * Envoie un email de réinitialisation de mot de passe.
 * L'utilisateur clique sur le lien reçu, qui le redirige vers /update-password
 * avec une session temporaire déjà active (gérée par Supabase Auth).
 */
export async function requestPasswordReset(email: string): Promise<AuthResult> {
  const supabase = createClient();
  const { error } = await supabase.auth.resetPasswordForEmail(email, {
    redirectTo: `${window.location.origin}/update-password`,
  });
  if (error) return { success: false, error: translateAuthError(error.message) };
  return { success: true };
}

/**
 * Met à jour le mot de passe — appelé depuis /update-password après le clic
 * sur le lien de réinitialisation, ou depuis les paramètres du compte.
 */
export async function updatePassword(newPassword: string): Promise<AuthResult> {
  const supabase = createClient();
  const { error } = await supabase.auth.updateUser({ password: newPassword });
  if (error) return { success: false, error: translateAuthError(error.message) };
  return { success: true };
}

/**
 * Inscription — réservée aux flux où un administrateur crée un compte
 * (élève, parent, professeur). Le profil est créé automatiquement par le
 * trigger handle_new_user() avec le rôle transmis dans les métadonnées.
 */
export async function signUp(params: {
  email: string;
  password: string;
  fullName: string;
  role: UserRole;
}): Promise<AuthResult> {
  const supabase = createClient();
  const { error, data } = await supabase.auth.signUp({
    email: params.email,
    password: params.password,
    options: {
      data: { full_name: params.fullName, role: params.role },
    },
  });
  if (error) return { success: false, error: translateAuthError(error.message) };
  return { success: true, data: data.user?.id as unknown as undefined };
}

/**
 * Récupère la session courante + le profil (rôle inclus) en un seul appel.
 * À utiliser côté client dans les composants qui ont besoin du rôle affiché.
 */
export async function getCurrentUserWithProfile() {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return null;

  const { data: profile } = await supabase
    .from("profiles")
    .select("*")
    .eq("id", user.id)
    .single();

  return profile;
}

function translateAuthError(message: string): string {
  const map: Record<string, string> = {
    "Invalid login credentials": "Email ou mot de passe incorrect.",
    "Email not confirmed": "Veuillez confirmer votre adresse email avant de vous connecter.",
    "User already registered": "Un compte existe déjà avec cet email.",
    "Password should be at least 6 characters": "Le mot de passe doit contenir au moins 6 caractères.",
    "For security purposes, you can only request this once every 60 seconds":
      "Pour des raisons de sécurité, veuillez patienter 60 secondes avant de réessayer.",
  };
  return map[message] ?? message;
}
