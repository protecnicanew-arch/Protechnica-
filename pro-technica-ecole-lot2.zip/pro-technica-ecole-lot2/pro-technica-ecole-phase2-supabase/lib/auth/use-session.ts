"use client";

import { useEffect, useState } from "react";
import { createClient } from "@/lib/supabase/client";
import type { Tables } from "@/lib/supabase/database.types";

type Profile = Tables<"profiles">;

interface SessionState {
  profile: Profile | null;
  loading: boolean;
}

/**
 * Hook client : expose le profil (avec rôle) de l'utilisateur connecté et
 * se met à jour automatiquement sur connexion/déconnexion/rafraîchissement
 * de token. À utiliser dans Header, Sidebar, gardes de permission côté UI, etc.
 */
export function useSession(): SessionState {
  const [state, setState] = useState<SessionState>({ profile: null, loading: true });

  useEffect(() => {
    const supabase = createClient();
    let mounted = true;

    async function loadProfile(userId: string) {
      const { data } = await supabase.from("profiles").select("*").eq("id", userId).single();
      if (mounted) setState({ profile: data, loading: false });
    }

    supabase.auth.getUser().then(({ data }) => {
      if (data.user) loadProfile(data.user.id);
      else if (mounted) setState({ profile: null, loading: false });
    });

    const { data: subscription } = supabase.auth.onAuthStateChange((_event, session) => {
      if (session?.user) loadProfile(session.user.id);
      else setState({ profile: null, loading: false });
    });

    return () => {
      mounted = false;
      subscription.subscription.unsubscribe();
    };
  }, []);

  return state;
}
