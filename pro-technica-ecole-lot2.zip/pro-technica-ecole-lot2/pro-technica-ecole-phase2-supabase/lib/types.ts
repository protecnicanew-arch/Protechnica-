// ============================================================
// PRO TECHNICA ÉCOLE — Types du domaine
// Conçus pour correspondre 1:1 aux futures tables Supabase.
// ============================================================

export type UserRole =
  | "administrateur"
  | "direction"
  | "comptable"
  | "professeur"
  | "etudiant"
  | "parent";

export interface User {
  id: string;
  fullName: string;
  email: string;
  role: UserRole;
  avatarUrl?: string;
  phone?: string;
  createdAt: string;
}

export type FiliereType = "BTS" | "Licence" | "Master" | "Formation professionnelle";

export interface Filiere {
  id: string;
  nom: string;
  type: FiliereType;
  dureeAnnees: number;
  description?: string;
}

export interface Classe {
  id: string;
  nom: string;
  filiereId: string;
  anneeScolaire: string;
  professeurPrincipalId?: string;
  effectifMax: number;
}

export type PaymentStatus = "paye" | "partiel" | "impaye" | "en_retard";

export interface Payment {
  id: string;
  studentId: string;
  libelle: string;
  montantDu: number;
  montantPaye: number;
  date: string;
  status: PaymentStatus;
  recuUrl?: string;
}

export interface Student {
  id: string;
  matricule: string;
  fullName: string;
  photoUrl?: string;
  email: string;
  phone: string;
  classeId: string;
  filiereId: string;
  parentId?: string;
  dateNaissance: string;
  dateInscription: string;
  statut: "actif" | "suspendu" | "diplome" | "abandon";
  soldeRestant: number;
}

export interface Teacher {
  id: string;
  fullName: string;
  photoUrl?: string;
  email: string;
  phone: string;
  matieres: string[];
  classesIds: string[];
  dateEmbauche: string;
}

export type AttendanceStatus = "present" | "absent" | "retard" | "justifie";

export interface Attendance {
  id: string;
  personId: string;
  personType: "etudiant" | "professeur";
  date: string;
  status: AttendanceStatus;
  classeId?: string;
}

export interface Grade {
  id: string;
  studentId: string;
  matiere: string;
  type: "controle" | "devoir" | "examen";
  note: number;
  bareme: number;
  coefficient: number;
  date: string;
  professeurId: string;
}

export interface Bulletin {
  id: string;
  studentId: string;
  periode: string;
  moyenneGenerale: number;
  rang: number;
  effectifClasse: number;
  appreciation: string;
}

export interface Actualite {
  id: string;
  titre: string;
  contenu: string;
  auteurId: string;
  date: string;
  type: "annonce" | "evenement" | "publication";
  imageUrl?: string;
}

export interface DashboardStats {
  revenusMois: number;
  revenusMoisPrecedent: number;
  etudiantsInscrits: number;
  etudiantsMoisPrecedent: number;
  professeursActifs: number;
  tauxPresenceMoyen: number;
}

export interface ScheduleSlot {
  id: string;
  teacherId: string;
  classeId: string;
  matiere: string;
  jour: "Lundi" | "Mardi" | "Mercredi" | "Jeudi" | "Vendredi" | "Samedi";
  heureDebut: string;
  heureFin: string;
  salle?: string;
}

export interface ActivityLogEntry {
  id: string;
  userId: string;
  userName: string;
  action: string;
  date: string;
}
