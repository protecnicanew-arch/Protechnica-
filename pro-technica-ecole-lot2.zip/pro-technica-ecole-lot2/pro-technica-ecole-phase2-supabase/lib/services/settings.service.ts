import { createClient } from "@/lib/supabase/client";

// school_settings est une table clé/valeur (clé unique, valeur jsonb) — on
// l'expose ici comme un simple objet plat { nom_ecole: "...", annee_active: "...", ... }
// pratique à consommer depuis un formulaire de paramètres.

export async function getSettings(): Promise<Record<string, unknown>> {
  const supabase = createClient();
  const { data, error } = await supabase.from("school_settings").select("cle, valeur");
  if (error) throw error;
  const result: Record<string, unknown> = {};
  for (const row of data ?? []) result[row.cle] = row.valeur;
  return result;
}

export async function setSetting(cle: string, valeur: unknown, updatedBy: string) {
  const supabase = createClient();
  const { error } = await supabase
    .from("school_settings")
    .upsert({ cle, valeur: valeur as never, updated_by: updatedBy }, { onConflict: "cle" });
  if (error) throw error;
}
