import { createClient } from "@/lib/supabase/client";

export type Bucket =
  | "student-photos"
  | "teacher-photos"
  | "documents"
  | "bulletins"
  | "receipts"
  | "school-assets";

/**
 * Upload un fichier dans un bucket. Pour les buckets privés (documents,
 * bulletins, receipts), le chemin DOIT commencer par "<ownerId>/" — c'est
 * cette convention que les politiques RLS de storage.objects vérifient.
 */
export async function uploadFile(params: {
  bucket: Bucket;
  path: string; // ex: `${studentId}/photo.jpg` ou `${studentId}/bulletin-t1.pdf`
  file: File | Blob;
  upsert?: boolean;
}): Promise<{ path: string }> {
  const supabase = createClient();
  const { data, error } = await supabase.storage
    .from(params.bucket)
    .upload(params.path, params.file, { upsert: params.upsert ?? true, cacheControl: "3600" });
  if (error) throw error;
  return { path: data.path };
}

/** URL publique directe — uniquement pour les buckets publics (photos, school-assets). */
export function getPublicUrl(bucket: Bucket, path: string): string {
  const supabase = createClient();
  return supabase.storage.from(bucket).getPublicUrl(path).data.publicUrl;
}

/** URL signée temporaire — pour les buckets privés (documents, bulletins, receipts). */
export async function getSignedUrl(bucket: Bucket, path: string, expiresInSeconds = 3600): Promise<string> {
  const supabase = createClient();
  const { data, error } = await supabase.storage.from(bucket).createSignedUrl(path, expiresInSeconds);
  if (error) throw error;
  return data.signedUrl;
}

export async function deleteFile(bucket: Bucket, path: string): Promise<void> {
  const supabase = createClient();
  const { error } = await supabase.storage.from(bucket).remove([path]);
  if (error) throw error;
}

export async function listFiles(bucket: Bucket, folder: string) {
  const supabase = createClient();
  const { data, error } = await supabase.storage.from(bucket).list(folder);
  if (error) throw error;
  return data ?? [];
}
