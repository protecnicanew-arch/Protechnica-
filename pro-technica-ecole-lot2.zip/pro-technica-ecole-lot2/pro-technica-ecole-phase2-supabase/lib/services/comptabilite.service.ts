import { createClient } from "@/lib/supabase/client";

export interface Expense {
  id: string;
  libelle: string;
  categorie: string;
  montant: number;
  date: string;
  justificatifUrl?: string;
}

export async function listExpenses(fromDate?: string, toDate?: string): Promise<Expense[]> {
  const supabase = createClient();
  let query = supabase.from("expenses").select("*").order("date", { ascending: false });
  if (fromDate) query = query.gte("date", fromDate);
  if (toDate) query = query.lte("date", toDate);
  const { data, error } = await query;
  if (error) throw error;
  return (data ?? []).map((r) => ({
    id: r.id, libelle: r.libelle, categorie: r.categorie, montant: Number(r.montant),
    date: r.date, justificatifUrl: r.justificatif_url ?? undefined,
  }));
}

export async function createExpense(params: {
  libelle: string; categorie: string; montant: number; date: string; createdBy: string; justificatifUrl?: string;
}) {
  const supabase = createClient();
  const { error } = await supabase.from("expenses").insert({
    libelle: params.libelle, categorie: params.categorie, montant: params.montant,
    date: params.date, created_by: params.createdBy, justificatif_url: params.justificatifUrl,
  });
  if (error) throw error;
}

export async function deleteExpense(id: string) {
  const supabase = createClient();
  const { error } = await supabase.from("expenses").delete().eq("id", id);
  if (error) throw error;
}

/** Rapport recettes/dépenses sur une période, pour export Excel/PDF. */
export async function getFinancialReport(fromDate: string, toDate: string) {
  const supabase = createClient();

  const [{ data: installments, error: e1 }, { data: expenses, error: e2 }] = await Promise.all([
    supabase.from("payment_installments").select("montant, date_paiement, mode_paiement").gte("date_paiement", fromDate).lte("date_paiement", toDate),
    supabase.from("expenses").select("montant, date, categorie").gte("date", fromDate).lte("date", toDate),
  ]);
  if (e1) throw e1;
  if (e2) throw e2;

  const totalRecettes = (installments ?? []).reduce((s, r) => s + Number(r.montant), 0);
  const totalDepenses = (expenses ?? []).reduce((s, r) => s + Number(r.montant), 0);

  return {
    periode: { fromDate, toDate },
    totalRecettes,
    totalDepenses,
    solde: totalRecettes - totalDepenses,
    recettes: installments ?? [],
    depenses: expenses ?? [],
  };
}
