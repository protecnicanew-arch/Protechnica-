import { createClient } from "@/lib/supabase/client";
import type { Filiere, Classe } from "@/lib/types";

// -------- Filières (= "programs" en base) --------

function mapFiliere(row: {
  id: string; nom: string; type: Filiere["type"]; duree_annees: number; description: string | null;
}): Filiere {
  return { id: row.id, nom: row.nom, type: row.type, dureeAnnees: row.duree_annees, description: row.description ?? undefined };
}

export async function listFilieres(): Promise<Filiere[]> {
  const supabase = createClient();
  const { data, error } = await supabase.from("programs").select("*").order("nom");
  if (error) throw error;
  return (data ?? []).map(mapFiliere);
}

export async function createFiliere(input: Omit<Filiere, "id">) {
  const supabase = createClient();
  const { error } = await supabase.from("programs").insert({
    nom: input.nom, type: input.type, duree_annees: input.dureeAnnees, description: input.description,
  });
  if (error) throw error;
}

export async function updateFiliere(id: string, input: Omit<Filiere, "id">) {
  const supabase = createClient();
  const { error } = await supabase
    .from("programs")
    .update({ nom: input.nom, type: input.type, duree_annees: input.dureeAnnees, description: input.description })
    .eq("id", id);
  if (error) throw error;
}

export async function deleteFiliere(id: string) {
  const supabase = createClient();
  const { error } = await supabase.from("programs").delete().eq("id", id);
  if (error) throw error;
}

// -------- Classes --------

function mapClasse(row: {
  id: string; nom: string; program_id: string; annee_scolaire: string;
  professeur_principal_id: string | null; effectif_max: number;
}): Classe {
  return {
    id: row.id, nom: row.nom, filiereId: row.program_id, anneeScolaire: row.annee_scolaire,
    professeurPrincipalId: row.professeur_principal_id ?? undefined, effectifMax: row.effectif_max,
  };
}

export async function listClasses(): Promise<Classe[]> {
  const supabase = createClient();
  const { data, error } = await supabase.from("classes").select("*").order("nom");
  if (error) throw error;
  return (data ?? []).map(mapClasse);
}

export async function createClasse(input: Omit<Classe, "id">) {
  const supabase = createClient();
  const { error } = await supabase.from("classes").insert({
    nom: input.nom, program_id: input.filiereId, annee_scolaire: input.anneeScolaire,
    professeur_principal_id: input.professeurPrincipalId, effectif_max: input.effectifMax,
  });
  if (error) throw error;
}

export async function updateClasse(id: string, input: Omit<Classe, "id">) {
  const supabase = createClient();
  const { error } = await supabase
    .from("classes")
    .update({
      nom: input.nom, program_id: input.filiereId, annee_scolaire: input.anneeScolaire,
      professeur_principal_id: input.professeurPrincipalId, effectif_max: input.effectifMax,
    })
    .eq("id", id);
  if (error) throw error;
}

export async function deleteClasse(id: string) {
  const supabase = createClient();
  const { error } = await supabase.from("classes").delete().eq("id", id);
  if (error) throw error;
}

// -------- Matières --------

export async function listSubjects() {
  const supabase = createClient();
  const { data, error } = await supabase.from("subjects").select("*").order("nom");
  if (error) throw error;
  return data ?? [];
}
