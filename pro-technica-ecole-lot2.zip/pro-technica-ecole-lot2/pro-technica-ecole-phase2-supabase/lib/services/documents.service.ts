import { createClient } from "@/lib/supabase/client";
import { uploadFile, getSignedUrl, deleteFile } from "./storage.service";

export interface StudentDocument {
  id: string;
  nom: string;
  type: string | null;
  storagePath: string;
  tailleOctets: number | null;
  createdAt: string;
}

export async function listDocumentsForOwner(ownerId: string): Promise<StudentDocument[]> {
  const supabase = createClient();
  const { data, error } = await supabase
    .from("documents")
    .select("*")
    .eq("owner_id", ownerId)
    .order("created_at", { ascending: false });
  if (error) throw error;
  return (data ?? []).map((r) => ({
    id: r.id, nom: r.nom, type: r.type, storagePath: r.storage_path,
    tailleOctets: r.taille_octets, createdAt: r.created_at,
  }));
}

/**
 * Upload le fichier dans le bucket privé "documents" (chemin `${ownerId}/...`,
 * requis par la politique RLS de storage.objects) puis enregistre la ligne
 * dans la table `documents`.
 */
export async function uploadDocument(params: {
  ownerId: string;
  ownerType: "etudiant" | "professeur";
  file: File;
  nom: string;
  uploadedBy: string;
}): Promise<void> {
  const safeName = params.file.name.replace(/[^a-zA-Z0-9._-]/g, "_");
  const path = `${params.ownerId}/${Date.now()}-${safeName}`;

  const { path: storedPath } = await uploadFile({ bucket: "documents", path, file: params.file });

  const supabase = createClient();
  const { error } = await supabase.from("documents").insert({
    owner_id: params.ownerId,
    owner_type: params.ownerType,
    nom: params.nom,
    type: params.file.type || null,
    storage_path: storedPath,
    taille_octets: params.file.size,
    uploaded_by: params.uploadedBy,
  });
  if (error) throw error;
}

export async function downloadDocument(storagePath: string): Promise<string> {
  return getSignedUrl("documents", storagePath, 300);
}

export async function deleteDocument(id: string, storagePath: string): Promise<void> {
  await deleteFile("documents", storagePath);
  const supabase = createClient();
  const { error } = await supabase.from("documents").delete().eq("id", id);
  if (error) throw error;
}
