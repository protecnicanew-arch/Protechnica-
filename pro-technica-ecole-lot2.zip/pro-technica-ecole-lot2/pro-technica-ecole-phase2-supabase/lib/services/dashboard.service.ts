import { createClient } from "@/lib/supabase/client";
import type { DashboardStats, ActivityLogEntry } from "@/lib/types";
import { getMonthlyRevenue } from "./payments.service";
import { getAverageAttendanceRate } from "./attendance.service";

function startOfMonth(offsetMonths = 0): string {
  const d = new Date();
  d.setMonth(d.getMonth() + offsetMonths, 1);
  d.setHours(0, 0, 0, 0);
  return d.toISOString().slice(0, 10);
}

export async function getDashboardStats(): Promise<DashboardStats> {
  const supabase = createClient();

  const [
    { count: etudiantsInscrits },
    { count: etudiantsMoisPrecedent },
    { count: professeursActifs },
    revenusMois,
    revenusMoisPrecedent,
    tauxPresenceMoyen,
  ] = await Promise.all([
    supabase.from("students").select("id", { count: "exact", head: true }),
    supabase.from("students").select("id", { count: "exact", head: true }).lt("date_inscription", startOfMonth()),
    supabase.from("teachers").select("id", { count: "exact", head: true }).eq("is_active", true),
    getMonthlyRevenue(startOfMonth()),
    getMonthlyRevenue(startOfMonth(-1)).then(async (fromStart) => {
      // revenus du mois précédent uniquement (borné par le début du mois courant)
      const supabase2 = createClient();
      const { data } = await supabase2
        .from("payment_installments")
        .select("montant")
        .gte("date_paiement", startOfMonth(-1))
        .lt("date_paiement", startOfMonth());
      return (data ?? []).reduce((s, r) => s + Number(r.montant), 0) || fromStart;
    }),
    getAverageAttendanceRate(startOfMonth()),
  ]);

  return {
    revenusMois,
    revenusMoisPrecedent,
    etudiantsInscrits: etudiantsInscrits ?? 0,
    etudiantsMoisPrecedent: etudiantsMoisPrecedent ?? 0,
    professeursActifs: professeursActifs ?? 0,
    tauxPresenceMoyen,
  };
}

const MOIS_FR = ["Jan", "Fév", "Mar", "Avr", "Mai", "Juin", "Juil", "Août", "Sept", "Oct", "Nov", "Déc"];

/** Revenus encaissés (versements) sur les 6 derniers mois, pour le graphique du dashboard. */
export async function getRevenueSeries(): Promise<{ mois: string; revenus: number }[]> {
  const supabase = createClient();
  const from = startOfMonth(-5);
  const { data, error } = await supabase
    .from("payment_installments")
    .select("montant, date_paiement")
    .gte("date_paiement", from);
  if (error) throw error;

  const buckets = new Map<string, number>();
  for (let i = 5; i >= 0; i--) {
    const d = new Date();
    d.setMonth(d.getMonth() - i, 1);
    buckets.set(MOIS_FR[d.getMonth()], 0);
  }
  for (const row of data ?? []) {
    const mois = MOIS_FR[new Date(row.date_paiement).getMonth()];
    if (buckets.has(mois)) buckets.set(mois, (buckets.get(mois) ?? 0) + Number(row.montant));
  }
  return [...buckets.entries()].map(([mois, revenus]) => ({ mois, revenus }));
}

/** Répartition du nombre d'étudiants actifs par filière, pour le graphique du dashboard. */
export async function getEnrollmentByFiliere(): Promise<{ filiere: string; etudiants: number }[]> {
  const supabase = createClient();
  const { data, error } = await supabase
    .from("students")
    .select("program:programs(nom)")
    .eq("statut", "actif");
  if (error) throw error;

  const counts = new Map<string, number>();
  for (const row of data ?? []) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const nom = (row.program as any)?.nom ?? "Non affecté";
    counts.set(nom, (counts.get(nom) ?? 0) + 1);
  }
  return [...counts.entries()].map(([filiere, etudiants]) => ({ filiere, etudiants }));
}

/** Dernières entrées d'audit, pour le fil "Activités récentes" du dashboard admin. */
export async function getRecentActivity(limit = 10): Promise<ActivityLogEntry[]> {
  const supabase = createClient();
  const { data, error } = await supabase
    .from("audit_logs")
    .select("id, user_id, user_name, action, table_name, created_at")
    .order("created_at", { ascending: false })
    .limit(limit);
  if (error) throw error;
  return (data ?? []).map((r) => ({
    id: r.id,
    userId: r.user_id ?? "",
    userName: r.user_name ?? "Système",
    action: `${r.action}${r.table_name ? ` — ${r.table_name}` : ""}`,
    date: r.created_at,
  }));
}
