import { createClient } from "@/lib/supabase/client";
import type { Student } from "@/lib/types";

// Le frontend attend un objet "Student" plat (fullName, email, phone...) alors
// que ces champs vivent dans `profiles` (1 profil = 1 utilisateur Auth).
// On joint systématiquement `profiles` et on aplatit le résultat ici, pour
// que les composants existants (StudentsTable, etc.) n'aient rien à changer.
const STUDENT_SELECT = `
  id, matricule, photo_url, classe_id, program_id, date_naissance,
  date_inscription, statut, solde_restant, qr_code,
  profile:profiles!students_id_fkey ( full_name, email, phone )
`;

// eslint-disable-next-line @typescript-eslint/no-explicit-any
function mapStudent(row: any): Student {
  return {
    id: row.id,
    matricule: row.matricule,
    fullName: row.profile?.full_name ?? "",
    email: row.profile?.email ?? "",
    phone: row.profile?.phone ?? "",
    photoUrl: row.photo_url ?? undefined,
    classeId: row.classe_id,
    filiereId: row.program_id,
    dateNaissance: row.date_naissance,
    dateInscription: row.date_inscription,
    statut: row.statut,
    soldeRestant: Number(row.solde_restant),
  };
}

export async function listStudents(): Promise<Student[]> {
  const supabase = createClient();
  const { data, error } = await supabase
    .from("students")
    .select(STUDENT_SELECT)
    .order("created_at", { ascending: false });
  if (error) throw error;
  return (data ?? []).map(mapStudent);
}

export async function getStudent(id: string): Promise<Student | null> {
  const supabase = createClient();
  const { data, error } = await supabase.from("students").select(STUDENT_SELECT).eq("id", id).single();
  if (error) return null;
  return mapStudent(data);
}

export async function listStudentsByClasse(classeId: string): Promise<Student[]> {
  const supabase = createClient();
  const { data, error } = await supabase.from("students").select(STUDENT_SELECT).eq("classe_id", classeId);
  if (error) throw error;
  return (data ?? []).map(mapStudent);
}

/**
 * Crée un étudiant : suppose que le compte Auth existe déjà (créé par un
 * administrateur via l'invitation email, ou par signUp) et que son profil a
 * été généré par le trigger handle_new_user(). `profileId` = l'UUID Auth.
 */
export async function createStudent(params: {
  profileId: string;
  matricule: string;
  classeId: string;
  programId: string;
  dateNaissance?: string;
}) {
  const supabase = createClient();
  const { error } = await supabase.from("students").insert({
    id: params.profileId,
    matricule: params.matricule,
    classe_id: params.classeId,
    program_id: params.programId,
    date_naissance: params.dateNaissance,
  });
  if (error) throw error;
}

export async function reassignStudentClasse(studentId: string, classeId: string) {
  const supabase = createClient();
  const { error } = await supabase.from("students").update({ classe_id: classeId }).eq("id", studentId);
  if (error) throw error;
}

export async function updateStudentStatus(studentId: string, statut: Student["statut"]) {
  const supabase = createClient();
  const { error } = await supabase.from("students").update({ statut }).eq("id", studentId);
  if (error) throw error;
}

export async function deleteStudent(studentId: string) {
  const supabase = createClient();
  // La suppression du profil (cascade) supprime aussi l'étudiant, ses notes,
  // présences, paiements, etc. — utiliser plutôt updateStudentStatus('abandon')
  // en production pour conserver l'historique.
  const { error } = await supabase.from("profiles").delete().eq("id", studentId);
  if (error) throw error;
}
