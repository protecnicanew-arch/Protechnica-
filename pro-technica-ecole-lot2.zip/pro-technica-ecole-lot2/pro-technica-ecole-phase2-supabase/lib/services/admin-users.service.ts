// ============================================================
// Appelle la route serveur /api/admin/create-user (clé service_role côté
// serveur) pour créer un compte étudiant ou professeur sans jamais exposer
// la clé service_role au navigateur ni déconnecter l'administrateur.
// ============================================================

export interface CreateStudentAccountParams {
  fullName: string;
  email: string;
  password: string;
  phone?: string;
  matricule: string;
  classeId: string;
  programId: string;
  dateNaissance?: string;
}

export interface CreateTeacherAccountParams {
  fullName: string;
  email: string;
  password: string;
  phone?: string;
  matricule: string;
  specialite?: string;
  dateEmbauche?: string;
  matiereIds?: string[];
  classeIds?: string[];
}

async function postCreateUser(payload: Record<string, unknown>): Promise<{ id: string }> {
  const res = await fetch("/api/admin/create-user", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error ?? "Échec de la création du compte.");
  return data;
}

export function createStudentAccount(params: CreateStudentAccountParams) {
  return postCreateUser({ role: "etudiant", ...params });
}

export function createTeacherAccount(params: CreateTeacherAccountParams) {
  return postCreateUser({ role: "professeur", ...params });
}
