import { createClient } from "@/lib/supabase/client";
import type { ScheduleSlot } from "@/lib/types";

export async function listScheduleByTeacher(teacherId: string): Promise<ScheduleSlot[]> {
  const supabase = createClient();
  const { data, error } = await supabase
    .from("schedules")
    .select("id, teacher_id, classe_id, jour, heure_debut, heure_fin, salle, subject:subjects(nom)")
    .eq("teacher_id", teacherId);
  if (error) throw error;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  return (data ?? []).map((r: any) => ({
    id: r.id,
    teacherId: r.teacher_id,
    classeId: r.classe_id,
    matiere: r.subject?.nom ?? "",
    jour: r.jour,
    heureDebut: r.heure_debut,
    heureFin: r.heure_fin,
    salle: r.salle ?? undefined,
  }));
}

export async function listScheduleByClasse(classeId: string): Promise<ScheduleSlot[]> {
  const supabase = createClient();
  const { data, error } = await supabase
    .from("schedules")
    .select("id, teacher_id, classe_id, jour, heure_debut, heure_fin, salle, subject:subjects(nom)")
    .eq("classe_id", classeId);
  if (error) throw error;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  return (data ?? []).map((r: any) => ({
    id: r.id,
    teacherId: r.teacher_id,
    classeId: r.classe_id,
    matiere: r.subject?.nom ?? "",
    jour: r.jour,
    heureDebut: r.heure_debut,
    heureFin: r.heure_fin,
    salle: r.salle ?? undefined,
  }));
}

export async function createScheduleSlot(params: {
  classeId: string; subjectId: string; teacherId: string;
  jour: ScheduleSlot["jour"]; heureDebut: string; heureFin: string; salle?: string;
}) {
  const supabase = createClient();
  const { error } = await supabase.from("schedules").insert({
    classe_id: params.classeId, subject_id: params.subjectId, teacher_id: params.teacherId,
    jour: params.jour, heure_debut: params.heureDebut, heure_fin: params.heureFin, salle: params.salle,
  });
  if (error) throw error;
}

export async function deleteScheduleSlot(id: string) {
  const supabase = createClient();
  const { error } = await supabase.from("schedules").delete().eq("id", id);
  if (error) throw error;
}
