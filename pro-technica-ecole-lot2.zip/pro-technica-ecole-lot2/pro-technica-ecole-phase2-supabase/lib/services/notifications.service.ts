import { createClient } from "@/lib/supabase/client";
import type { RealtimeChannel } from "@supabase/supabase-js";

export interface AppNotification {
  id: string;
  titre: string;
  message: string;
  type: string;
  lien?: string;
  lu: boolean;
  createdAt: string;
}

function mapNotification(row: {
  id: string; titre: string; message: string; type: string; lien: string | null; lu: boolean; created_at: string;
}): AppNotification {
  return { id: row.id, titre: row.titre, message: row.message, type: row.type, lien: row.lien ?? undefined, lu: row.lu, createdAt: row.created_at };
}

export async function listNotifications(userId: string): Promise<AppNotification[]> {
  const supabase = createClient();
  const { data, error } = await supabase
    .from("notifications")
    .select("*")
    .eq("user_id", userId)
    .order("created_at", { ascending: false })
    .limit(50);
  if (error) throw error;
  return (data ?? []).map(mapNotification);
}

export async function markNotificationRead(id: string) {
  const supabase = createClient();
  const { error } = await supabase.from("notifications").update({ lu: true }).eq("id", id);
  if (error) throw error;
}

export async function markAllNotificationsRead(userId: string) {
  const supabase = createClient();
  const { error } = await supabase.from("notifications").update({ lu: true }).eq("user_id", userId).eq("lu", false);
  if (error) throw error;
}

export async function pushNotification(params: { userId: string; titre: string; message: string; type?: string; lien?: string }) {
  const supabase = createClient();
  const { error } = await supabase.from("notifications").insert({
    user_id: params.userId, titre: params.titre, message: params.message, type: params.type ?? "info", lien: params.lien,
  });
  if (error) throw error;
}

/**
 * S'abonne en temps réel aux nouvelles notifications de l'utilisateur.
 * À appeler dans un useEffect (Header, cloche de notifications) et à
 * désabonner (`channel.unsubscribe()`) au démontage du composant.
 *
 * Exemple :
 *   useEffect(() => {
 *     const channel = subscribeToNotifications(userId, (n) => toast(n.titre));
 *     return () => { channel.unsubscribe(); };
 *   }, [userId]);
 */
export function subscribeToNotifications(
  userId: string,
  onInsert: (notification: AppNotification) => void
): RealtimeChannel {
  const supabase = createClient();
  return supabase
    .channel(`notifications:${userId}`)
    .on(
      "postgres_changes",
      { event: "INSERT", schema: "public", table: "notifications", filter: `user_id=eq.${userId}` },
      (payload) => onInsert(mapNotification(payload.new as never))
    )
    .subscribe();
}

/** S'abonne aux nouveaux paiements reçus (pour un dashboard admin/comptable en direct). */
export function subscribeToPayments(onChange: () => void): RealtimeChannel {
  const supabase = createClient();
  return supabase
    .channel("payments-realtime")
    .on("postgres_changes", { event: "*", schema: "public", table: "payment_installments" }, onChange)
    .subscribe();
}

/** S'abonne aux nouvelles inscriptions d'étudiants. */
export function subscribeToNewStudents(onInsert: () => void): RealtimeChannel {
  const supabase = createClient();
  return supabase
    .channel("students-realtime")
    .on("postgres_changes", { event: "INSERT", schema: "public", table: "students" }, onInsert)
    .subscribe();
}
