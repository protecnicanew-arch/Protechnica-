# Schéma & Sécurité — PRO TECHNICA ÉCOLE

Projet Supabase : **Protechnica** (`aydvajqnxspeaiolzite`, région eu-west-1, Postgres 17).

## Vue d'ensemble des 26 tables

| Domaine | Tables |
|---|---|
| Identité | `profiles` (extension de `auth.users`), `teachers`, `parents`, `students` |
| Structure académique | `departments`, `programs` (filières), `classes`, `subjects`, `teacher_subjects`, `teacher_classes`, `student_parents`, `schedules` |
| Vie scolaire | `attendance`, `attendance_details`, `exams`, `grades`, `report_cards`, `student_cards` |
| Finance | `payments`, `payment_installments`, `expenses` |
| Communication | `announcements`, `notifications`, `documents`, `library_resources` |
| Gouvernance | `audit_logs`, `school_settings` |

> **Note de conception** : le cahier des charges listait `profiles` et
> `users` comme deux tables distinctes. En pratique, Supabase Auth fournit
> déjà `auth.users` (identifiants, mots de passe, sessions) ; `profiles`
> l'étend avec les données métier (nom, rôle, téléphone...). Créer une
> troisième table "users" aurait dupliqué `auth.users` sans bénéfice — c'est
> le pattern standard recommandé par Supabase.

## Rôles

`administrateur`, `direction`, `comptable`, `professeur`, `etudiant`, `parent`
— stockés dans `profiles.role` (type enum `user_role`).

## Sécurité RLS — principe

RLS est **activée sur les 26 tables**. Les règles s'appuient sur des fonctions
utilitaires `security definer` (`lib` SQL, migration `08_rls_helper_functions`)
qui évitent la récursion RLS :

- `is_admin_or_direction()` — admin ou direction : accès total
- `is_comptable_or_above()` — + comptable : accès à la finance
- `is_teacher_of_classe(classe_id)` / `is_teacher_of_student(student_id)` — un professeur ne voit que ses classes affectées (`teacher_classes`) ou dont il est professeur principal
- `is_parent_of_student(student_id)` — un parent ne voit que ses enfants (`student_parents`)

### Résumé par rôle

| Rôle | Étudiants | Notes/Présences | Paiements | Comptabilité | Admin (users, réglages) |
|---|---|---|---|---|---|
| Administrateur | Tout | Tout | Tout | Tout | Tout |
| Direction | Tout | Lecture | Lecture/écriture | Lecture/écriture | Réglages |
| Comptable | Lecture | — | Tout | Tout | — |
| Professeur | Ses classes | Ses classes | — | — | — |
| Étudiant | Lui-même | Lui-même (lecture) | Lui-même (lecture) | — | — |
| Parent | Ses enfants | Ses enfants (lecture) | Ses enfants (lecture) | — | — |

`audit_logs` : lecture réservée admin/direction. Aucune écriture manuelle
possible (uniquement via triggers `security definer` sur students, payments,
payment_installments, grades).

## Automatisations (triggers)

- `handle_new_user` — crée automatiquement le `profile` à l'inscription Auth
- `recompute_payment_status` — recalcule `payments.status` et
  `students.solde_restant` à chaque versement (`payment_installments`)
- `audit_trigger_fn` — journalise création/modification/suppression sur les
  tables sensibles
- `set_updated_at` — horodatage automatique

## Storage — 6 buckets

| Bucket | Public | Convention de chemin | Accès |
|---|---|---|---|
| `student-photos` | oui | `<id>.jpg` | lecture publique, écriture admin |
| `teacher-photos` | oui | `<id>.jpg` | lecture publique, écriture admin |
| `school-assets` | oui | libre | lecture publique, écriture admin |
| `documents` | non | `<owner_id>/<fichier>` | propriétaire + admin |
| `bulletins` | non | `<student_id>/<fichier>.pdf` | étudiant, parent, admin |
| `receipts` | non | `<student_id>/<fichier>.pdf` | étudiant, parent, comptabilité |

## Realtime

Tables diffusées en direct (`supabase_realtime`) : `notifications`,
`payments`, `payment_installments`, `students`, `announcements`,
`attendance_details`. Utilisées via `lib/services/notifications.service.ts`
(`subscribeToNotifications`, `subscribeToPayments`, `subscribeToNewStudents`).

## Performance

Index créés sur toutes les clés étrangères fréquemment filtrées (classe,
étudiant, date, statut...), plus deux index trigram (`pg_trgm`) pour la
recherche approximative par nom. Conçu pour tenir plusieurs milliers
d'étudiants et plusieurs années d'historique sans dégradation notable.
