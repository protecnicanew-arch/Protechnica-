# Déploiement Netlify — PRO TECHNICA ÉCOLE

## 1. Pré-requis

- Le dépôt Git du projet poussé sur GitHub/GitLab/Bitbucket
- Un compte Netlify avec le plugin `@netlify/plugin-nextjs` (déjà déclaré
  dans `netlify.toml`, installé automatiquement au build)

## 2. Créer le site

1. Netlify → **Add new site → Import an existing project**
2. Sélectionnez le dépôt
3. Netlify détecte `netlify.toml` : build command `npm run build`, publish `.next`

## 3. Variables d'environnement

Dans **Site settings → Environment variables**, ajoutez (mêmes noms que `.env.example`) :

| Variable | Valeur | Visibilité |
|---|---|---|
| `NEXT_PUBLIC_SUPABASE_URL` | `https://aydvajqnxspeaiolzite.supabase.co` | Build + Runtime |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | clé anon (voir `.env.example`) | Build + Runtime |
| `SUPABASE_SERVICE_ROLE_KEY` | clé service_role (dashboard Supabase) | Runtime uniquement, marquer **Sensitive** |

## 4. Configuration Supabase côté Auth

Dans le dashboard Supabase → **Authentication → URL Configuration** :

- **Site URL** : `https://<votre-site>.netlify.app` (ou votre domaine personnalisé)
- **Redirect URLs** : ajoutez `https://<votre-site>.netlify.app/**` (nécessaire
  pour que le lien de réinitialisation de mot de passe redirige correctement
  vers `/update-password` en production)

## 5. Déployer

Chaque push sur la branche configurée (ex. `main`) déclenche un build et
déploiement automatique. Le middleware (`middleware.ts`) tourne en Edge
Function Netlify et protège les routes `/dashboard/*`.

## 6. Domaine personnalisé + HTTPS

**Site settings → Domain management → Add custom domain**, puis suivez les
instructions DNS. Netlify provisionne automatiquement le certificat TLS
(Let's Encrypt).

## 7. Vérifications post-déploiement

- [ ] `/login` s'affiche et la connexion fonctionne avec le compte admin créé en local
- [ ] `/dashboard` charge les vraies données (étudiants, classes, etc.)
- [ ] La réinitialisation de mot de passe envoie un email et le lien redirige bien vers le domaine de production
- [ ] Upload d'une photo étudiant fonctionne (bucket `student-photos`)
- [ ] Les notifications temps réel s'affichent sans rechargement de page

## 8. Sauvegardes

Supabase effectue des sauvegardes automatiques quotidiennes sur les plans
payants (Pro et supérieurs) — à vérifier/activer dans **Project Settings →
Database → Backups** avant la mise en production avec des données réelles.
