-- ============================================================
-- RLS : ANNONCES, NOTIFICATIONS, DOCUMENTS, BIBLIOTHÈQUE, AUDIT, PARAMÈTRES
-- ============================================================
alter table public.announcements enable row level security;
alter table public.notifications enable row level security;
alter table public.documents enable row level security;
alter table public.library_resources enable row level security;
alter table public.audit_logs enable row level security;
alter table public.school_settings enable row level security;

create policy "announcements_select" on public.announcements for select
  using (cible_roles is null or public.current_role() = any(cible_roles) or public.is_admin_or_direction());
create policy "announcements_write_admin" on public.announcements for all
  using (public.is_admin_or_direction()) with check (public.is_admin_or_direction());

create policy "notifications_select_self" on public.notifications for select using (user_id = auth.uid());
create policy "notifications_update_self" on public.notifications for update using (user_id = auth.uid());
create policy "notifications_insert_system" on public.notifications for insert
  with check (public.is_admin_or_direction() or true);
create policy "notifications_delete_self_or_admin" on public.notifications for delete
  using (user_id = auth.uid() or public.is_admin_or_direction());

create policy "documents_select" on public.documents for select
  using (
    owner_id = auth.uid()
    or public.is_admin_or_direction()
    or (owner_type = 'etudiant' and public.is_teacher_of_student(owner_id))
    or (owner_type = 'etudiant' and public.is_parent_of_student(owner_id))
  );
create policy "documents_write" on public.documents for insert
  with check (owner_id = auth.uid() or public.is_admin_or_direction());
create policy "documents_delete" on public.documents for delete
  using (owner_id = auth.uid() or public.is_admin_or_direction());

create policy "library_select_all" on public.library_resources for select using (auth.role() = 'authenticated');
create policy "library_write_admin" on public.library_resources for all
  using (public.is_admin_or_direction()) with check (public.is_admin_or_direction());

create policy "audit_logs_select_admin" on public.audit_logs for select using (public.is_admin_or_direction());

create policy "settings_select_all" on public.school_settings for select using (auth.role() = 'authenticated');
create policy "settings_write_admin" on public.school_settings for all
  using (public.is_admin_or_direction()) with check (public.is_admin_or_direction());
