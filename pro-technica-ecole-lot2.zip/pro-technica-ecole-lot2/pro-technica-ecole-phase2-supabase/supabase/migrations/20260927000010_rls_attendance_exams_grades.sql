-- ============================================================
-- RLS : PRÉSENCES, EXAMENS, NOTES, BULLETINS
-- ============================================================
alter table public.attendance enable row level security;
alter table public.attendance_details enable row level security;
alter table public.exams enable row level security;
alter table public.grades enable row level security;
alter table public.report_cards enable row level security;

create policy "attendance_select" on public.attendance for select
  using (
    public.is_admin_or_direction()
    or (classe_id is not null and public.is_teacher_of_classe(classe_id))
    or teacher_id = auth.uid()
  );
create policy "attendance_write_teacher_or_admin" on public.attendance for insert
  with check (public.is_admin_or_direction() or (classe_id is not null and public.is_teacher_of_classe(classe_id)));
create policy "attendance_update_teacher_or_admin" on public.attendance for update
  using (public.is_admin_or_direction() or (classe_id is not null and public.is_teacher_of_classe(classe_id)));
create policy "attendance_delete_admin" on public.attendance for delete using (public.is_admin_or_direction());

create policy "attendance_details_select" on public.attendance_details for select
  using (
    person_id = auth.uid()
    or public.is_admin_or_direction()
    or public.is_parent_of_student(person_id)
    or exists (
      select 1 from public.attendance a
      where a.id = attendance_details.attendance_id
        and (public.is_admin_or_direction() or (a.classe_id is not null and public.is_teacher_of_classe(a.classe_id)))
    )
  );
create policy "attendance_details_write" on public.attendance_details for all
  using (
    public.is_admin_or_direction()
    or exists (
      select 1 from public.attendance a
      where a.id = attendance_details.attendance_id
        and a.classe_id is not null and public.is_teacher_of_classe(a.classe_id)
    )
  )
  with check (
    public.is_admin_or_direction()
    or exists (
      select 1 from public.attendance a
      where a.id = attendance_details.attendance_id
        and a.classe_id is not null and public.is_teacher_of_classe(a.classe_id)
    )
  );

create policy "exams_select" on public.exams for select
  using (
    public.is_admin_or_direction()
    or public.is_teacher_of_classe(classe_id)
    or exists (select 1 from public.students s where s.id = auth.uid() and s.classe_id = exams.classe_id)
    or exists (
      select 1 from public.students s join public.student_parents sp on sp.student_id = s.id
      where sp.parent_id = auth.uid() and s.classe_id = exams.classe_id
    )
  );
create policy "exams_write" on public.exams for all
  using (public.is_admin_or_direction() or public.is_teacher_of_classe(classe_id))
  with check (public.is_admin_or_direction() or public.is_teacher_of_classe(classe_id));

create policy "grades_select" on public.grades for select
  using (
    student_id = auth.uid()
    or public.is_admin_or_direction()
    or public.is_parent_of_student(student_id)
    or public.is_teacher_of_student(student_id)
  );
create policy "grades_write_teacher_or_admin" on public.grades for all
  using (public.is_admin_or_direction() or public.is_teacher_of_student(student_id))
  with check (public.is_admin_or_direction() or public.is_teacher_of_student(student_id));

create policy "report_cards_select" on public.report_cards for select
  using (
    student_id = auth.uid()
    or public.is_admin_or_direction()
    or public.is_parent_of_student(student_id)
    or public.is_teacher_of_student(student_id)
  );
create policy "report_cards_write_admin" on public.report_cards for all
  using (public.is_admin_or_direction()) with check (public.is_admin_or_direction());
