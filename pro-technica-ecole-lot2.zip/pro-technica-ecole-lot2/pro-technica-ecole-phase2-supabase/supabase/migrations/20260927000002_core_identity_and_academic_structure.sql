-- ============================================================
-- IDENTITÉ (profiles = extension de auth.users) & STRUCTURE ACADÉMIQUE
-- ============================================================

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  email text not null unique,
  role user_role not null default 'etudiant',
  phone text,
  avatar_url text,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
comment on table public.profiles is 'Extension de auth.users : identité + rôle de chaque utilisateur (admin, direction, comptable, professeur, étudiant, parent).';

create table public.departments (
  id uuid primary key default gen_random_uuid(),
  nom text not null unique,
  description text,
  created_at timestamptz not null default now()
);

create table public.programs (
  id uuid primary key default gen_random_uuid(),
  nom text not null,
  type program_type not null,
  duree_annees smallint not null default 1,
  description text,
  department_id uuid references public.departments(id) on delete set null,
  created_at timestamptz not null default now()
);

create table public.teachers (
  id uuid primary key references public.profiles(id) on delete cascade,
  matricule text not null unique,
  photo_url text,
  specialite text,
  date_embauche date not null default current_date,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.classes (
  id uuid primary key default gen_random_uuid(),
  nom text not null,
  program_id uuid not null references public.programs(id) on delete restrict,
  annee_scolaire text not null,
  professeur_principal_id uuid references public.teachers(id) on delete set null,
  effectif_max smallint not null default 40,
  created_at timestamptz not null default now(),
  unique (nom, annee_scolaire)
);

create table public.subjects (
  id uuid primary key default gen_random_uuid(),
  nom text not null,
  code text unique,
  coefficient_defaut numeric(4,2) not null default 1,
  department_id uuid references public.departments(id) on delete set null,
  created_at timestamptz not null default now()
);

create table public.teacher_subjects (
  teacher_id uuid not null references public.teachers(id) on delete cascade,
  subject_id uuid not null references public.subjects(id) on delete cascade,
  primary key (teacher_id, subject_id)
);

create table public.teacher_classes (
  teacher_id uuid not null references public.teachers(id) on delete cascade,
  classe_id uuid not null references public.classes(id) on delete cascade,
  primary key (teacher_id, classe_id)
);

create table public.parents (
  id uuid primary key references public.profiles(id) on delete cascade,
  photo_url text,
  profession text,
  created_at timestamptz not null default now()
);

create table public.students (
  id uuid primary key references public.profiles(id) on delete cascade,
  matricule text not null unique,
  photo_url text,
  qr_code text unique,
  classe_id uuid references public.classes(id) on delete set null,
  program_id uuid references public.programs(id) on delete set null,
  date_naissance date,
  date_inscription date not null default current_date,
  statut student_status not null default 'actif',
  solde_restant numeric(12,2) not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.student_parents (
  student_id uuid not null references public.students(id) on delete cascade,
  parent_id uuid not null references public.parents(id) on delete cascade,
  relation text default 'parent',
  primary key (student_id, parent_id)
);

create table public.schedules (
  id uuid primary key default gen_random_uuid(),
  classe_id uuid not null references public.classes(id) on delete cascade,
  subject_id uuid not null references public.subjects(id) on delete cascade,
  teacher_id uuid not null references public.teachers(id) on delete cascade,
  jour day_of_week not null,
  heure_debut time not null,
  heure_fin time not null,
  salle text,
  created_at timestamptz not null default now(),
  constraint schedules_heures_check check (heure_fin > heure_debut)
);

create table public.student_cards (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.students(id) on delete cascade,
  qr_code text not null unique,
  date_emission date not null default current_date,
  date_expiration date,
  statut text not null default 'active',
  created_at timestamptz not null default now()
);
