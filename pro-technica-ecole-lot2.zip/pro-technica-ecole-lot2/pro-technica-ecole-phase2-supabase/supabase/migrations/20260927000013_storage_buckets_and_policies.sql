-- ============================================================
-- STORAGE : buckets + politiques
-- ============================================================
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values
  ('student-photos', 'student-photos', true,  5242880, array['image/png','image/jpeg','image/webp']),
  ('teacher-photos', 'teacher-photos', true,  5242880, array['image/png','image/jpeg','image/webp']),
  ('documents',      'documents',      false, 20971520, null),
  ('bulletins',      'bulletins',      false, 10485760, array['application/pdf']),
  ('receipts',       'receipts',       false, 10485760, array['application/pdf']),
  ('school-assets',  'school-assets',  true,  5242880, array['image/png','image/jpeg','image/svg+xml','image/webp'])
on conflict (id) do nothing;

create policy "student_photos_read_public" on storage.objects for select
  using (bucket_id = 'student-photos');
create policy "student_photos_write_admin" on storage.objects for insert
  with check (bucket_id = 'student-photos' and public.is_admin_or_direction());
create policy "student_photos_update_admin" on storage.objects for update
  using (bucket_id = 'student-photos' and public.is_admin_or_direction());
create policy "student_photos_delete_admin" on storage.objects for delete
  using (bucket_id = 'student-photos' and public.is_admin_or_direction());

create policy "teacher_photos_read_public" on storage.objects for select
  using (bucket_id = 'teacher-photos');
create policy "teacher_photos_write_admin" on storage.objects for insert
  with check (bucket_id = 'teacher-photos' and public.is_admin_or_direction());
create policy "teacher_photos_update_admin" on storage.objects for update
  using (bucket_id = 'teacher-photos' and public.is_admin_or_direction());
create policy "teacher_photos_delete_admin" on storage.objects for delete
  using (bucket_id = 'teacher-photos' and public.is_admin_or_direction());

create policy "school_assets_read_public" on storage.objects for select
  using (bucket_id = 'school-assets');
create policy "school_assets_write_admin" on storage.objects for all
  using (bucket_id = 'school-assets' and public.is_admin_or_direction())
  with check (bucket_id = 'school-assets' and public.is_admin_or_direction());

create policy "documents_bucket_owner_or_admin_select" on storage.objects for select
  using (bucket_id = 'documents' and (public.is_admin_or_direction() or (storage.foldername(name))[1] = auth.uid()::text));
create policy "documents_bucket_owner_or_admin_write" on storage.objects for insert
  with check (bucket_id = 'documents' and (public.is_admin_or_direction() or (storage.foldername(name))[1] = auth.uid()::text));
create policy "documents_bucket_admin_manage" on storage.objects for update
  using (bucket_id = 'documents' and public.is_admin_or_direction());
create policy "documents_bucket_admin_delete" on storage.objects for delete
  using (bucket_id = 'documents' and public.is_admin_or_direction());

create policy "bulletins_select" on storage.objects for select
  using (
    bucket_id = 'bulletins' and (
      public.is_admin_or_direction()
      or (storage.foldername(name))[1] = auth.uid()::text
      or public.is_parent_of_student(((storage.foldername(name))[1])::uuid)
    )
  );
create policy "bulletins_write_admin" on storage.objects for all
  using (bucket_id = 'bulletins' and public.is_admin_or_direction())
  with check (bucket_id = 'bulletins' and public.is_admin_or_direction());

create policy "receipts_select" on storage.objects for select
  using (
    bucket_id = 'receipts' and (
      public.is_comptable_or_above()
      or (storage.foldername(name))[1] = auth.uid()::text
      or public.is_parent_of_student(((storage.foldername(name))[1])::uuid)
    )
  );
create policy "receipts_write_comptable" on storage.objects for all
  using (bucket_id = 'receipts' and public.is_comptable_or_above())
  with check (bucket_id = 'receipts' and public.is_comptable_or_above());
