-- ============================================================
-- RLS : FINANCE — PAIEMENTS, VERSEMENTS, DÉPENSES
-- ============================================================
alter table public.payments enable row level security;
alter table public.payment_installments enable row level security;
alter table public.expenses enable row level security;

create policy "payments_select" on public.payments for select
  using (
    student_id = auth.uid()
    or public.is_parent_of_student(student_id)
    or public.is_comptable_or_above()
  );
create policy "payments_write_comptable" on public.payments for all
  using (public.is_comptable_or_above()) with check (public.is_comptable_or_above());

create policy "installments_select" on public.payment_installments for select
  using (
    public.is_comptable_or_above()
    or exists (
      select 1 from public.payments p
      where p.id = payment_installments.payment_id
        and (p.student_id = auth.uid() or public.is_parent_of_student(p.student_id))
    )
  );
create policy "installments_write_comptable" on public.payment_installments for all
  using (public.is_comptable_or_above()) with check (public.is_comptable_or_above());

create policy "expenses_select_comptable" on public.expenses for select using (public.is_comptable_or_above());
create policy "expenses_write_comptable" on public.expenses for all
  using (public.is_comptable_or_above()) with check (public.is_comptable_or_above());
