-- ============================================================
-- REALTIME : tables diffusées en temps réel
-- ============================================================
alter publication supabase_realtime add table public.notifications;
alter publication supabase_realtime add table public.payments;
alter publication supabase_realtime add table public.payment_installments;
alter publication supabase_realtime add table public.students;
alter publication supabase_realtime add table public.announcements;
alter publication supabase_realtime add table public.attendance_details;

alter table public.notifications replica identity full;
alter table public.payments replica identity full;
alter table public.payment_installments replica identity full;
alter table public.students replica identity full;
alter table public.announcements replica identity full;
alter table public.attendance_details replica identity full;
