-- ============================================================
-- RLS : activation + politiques — PROFILES, ACADEMIC STRUCTURE
-- ============================================================
alter table public.profiles enable row level security;
alter table public.departments enable row level security;
alter table public.programs enable row level security;
alter table public.classes enable row level security;
alter table public.subjects enable row level security;
alter table public.teachers enable row level security;
alter table public.teacher_subjects enable row level security;
alter table public.teacher_classes enable row level security;
alter table public.parents enable row level security;
alter table public.students enable row level security;
alter table public.student_parents enable row level security;
alter table public.schedules enable row level security;
alter table public.student_cards enable row level security;

create policy "profiles_select_self_or_admin" on public.profiles for select
  using (id = auth.uid() or public.is_admin_or_direction());
create policy "profiles_update_self" on public.profiles for update
  using (id = auth.uid() or public.is_admin_or_direction());
create policy "profiles_insert_admin" on public.profiles for insert
  with check (public.is_admin_or_direction());
create policy "profiles_delete_admin" on public.profiles for delete
  using (public.is_admin_or_direction());

create policy "departments_select_all" on public.departments for select using (auth.role() = 'authenticated');
create policy "departments_write_admin" on public.departments for all
  using (public.is_admin_or_direction()) with check (public.is_admin_or_direction());

create policy "programs_select_all" on public.programs for select using (auth.role() = 'authenticated');
create policy "programs_write_admin" on public.programs for all
  using (public.is_admin_or_direction()) with check (public.is_admin_or_direction());

create policy "classes_select_all" on public.classes for select using (auth.role() = 'authenticated');
create policy "classes_write_admin" on public.classes for all
  using (public.is_admin_or_direction()) with check (public.is_admin_or_direction());

create policy "subjects_select_all" on public.subjects for select using (auth.role() = 'authenticated');
create policy "subjects_write_admin" on public.subjects for all
  using (public.is_admin_or_direction()) with check (public.is_admin_or_direction());

create policy "schedules_select_all" on public.schedules for select using (auth.role() = 'authenticated');
create policy "schedules_write_admin" on public.schedules for all
  using (public.is_admin_or_direction()) with check (public.is_admin_or_direction());

create policy "teachers_select_all" on public.teachers for select using (auth.role() = 'authenticated');
create policy "teachers_update_self_or_admin" on public.teachers for update
  using (id = auth.uid() or public.is_admin_or_direction());
create policy "teachers_write_admin" on public.teachers for insert with check (public.is_admin_or_direction());
create policy "teachers_delete_admin" on public.teachers for delete using (public.is_admin_or_direction());

create policy "teacher_subjects_select_all" on public.teacher_subjects for select using (auth.role() = 'authenticated');
create policy "teacher_subjects_write_admin" on public.teacher_subjects for all
  using (public.is_admin_or_direction()) with check (public.is_admin_or_direction());

create policy "teacher_classes_select_all" on public.teacher_classes for select using (auth.role() = 'authenticated');
create policy "teacher_classes_write_admin" on public.teacher_classes for all
  using (public.is_admin_or_direction()) with check (public.is_admin_or_direction());

create policy "parents_select" on public.parents for select
  using (id = auth.uid() or public.is_admin_or_direction() or public.is_comptable_or_above());
create policy "parents_update_self_or_admin" on public.parents for update
  using (id = auth.uid() or public.is_admin_or_direction());
create policy "parents_write_admin" on public.parents for insert with check (public.is_admin_or_direction());
create policy "parents_delete_admin" on public.parents for delete using (public.is_admin_or_direction());

create policy "students_select" on public.students for select
  using (
    id = auth.uid()
    or public.is_admin_or_direction()
    or public.is_comptable_or_above()
    or public.is_parent_of_student(id)
    or public.is_teacher_of_student(id)
  );
create policy "students_update_admin_or_self" on public.students for update
  using (public.is_admin_or_direction() or id = auth.uid());
create policy "students_insert_admin" on public.students for insert with check (public.is_admin_or_direction());
create policy "students_delete_admin" on public.students for delete using (public.is_admin_or_direction());

create policy "student_parents_select" on public.student_parents for select
  using (
    parent_id = auth.uid()
    or student_id = auth.uid()
    or public.is_admin_or_direction()
    or public.is_teacher_of_student(student_id)
  );
create policy "student_parents_write_admin" on public.student_parents for all
  using (public.is_admin_or_direction()) with check (public.is_admin_or_direction());

create policy "student_cards_select" on public.student_cards for select
  using (
    student_id = auth.uid()
    or public.is_admin_or_direction()
    or public.current_role() = 'professeur'
    or public.is_parent_of_student(student_id)
  );
create policy "student_cards_write_admin" on public.student_cards for all
  using (public.is_admin_or_direction()) with check (public.is_admin_or_direction());
