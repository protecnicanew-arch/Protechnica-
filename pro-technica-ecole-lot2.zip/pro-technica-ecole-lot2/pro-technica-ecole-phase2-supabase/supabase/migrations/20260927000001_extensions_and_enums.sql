-- ============================================================
-- PRO TECHNICA ÉCOLE — Extensions & types énumérés
-- ============================================================
create extension if not exists "pgcrypto";
create extension if not exists "pg_trgm";

do $$ begin
  create type user_role as enum ('administrateur','direction','comptable','professeur','etudiant','parent');
exception when duplicate_object then null; end $$;

do $$ begin
  create type program_type as enum ('BTS','Licence','Master','Formation professionnelle');
exception when duplicate_object then null; end $$;

do $$ begin
  create type student_status as enum ('actif','suspendu','diplome','abandon');
exception when duplicate_object then null; end $$;

do $$ begin
  create type payment_status as enum ('paye','partiel','impaye','en_retard');
exception when duplicate_object then null; end $$;

do $$ begin
  create type payment_type as enum ('inscription','scolarite','examen','autre');
exception when duplicate_object then null; end $$;

do $$ begin
  create type payment_mode as enum ('especes','virement','mobile_money','cheque','carte');
exception when duplicate_object then null; end $$;

do $$ begin
  create type attendance_status as enum ('present','absent','retard','justifie');
exception when duplicate_object then null; end $$;

do $$ begin
  create type person_type as enum ('etudiant','professeur');
exception when duplicate_object then null; end $$;

do $$ begin
  create type exam_type as enum ('controle','devoir','examen');
exception when duplicate_object then null; end $$;

do $$ begin
  create type day_of_week as enum ('Lundi','Mardi','Mercredi','Jeudi','Vendredi','Samedi');
exception when duplicate_object then null; end $$;

do $$ begin
  create type announcement_type as enum ('annonce','evenement','publication');
exception when duplicate_object then null; end $$;

do $$ begin
  create type document_owner_type as enum ('etudiant','professeur','classe','ecole');
exception when duplicate_object then null; end $$;

do $$ begin
  create type audit_action as enum ('creation','modification','suppression','connexion','deconnexion','paiement');
exception when duplicate_object then null; end $$;
