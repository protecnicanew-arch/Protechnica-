# Lot 2 — Points Importants du rapport d'audit (2026-09-27)

## Livré

8. **Upload de documents réel** (fiche étudiant → onglet Documents) :
   nouveau `lib/services/documents.service.ts`, branché sur la table
   `documents` + le bucket Storage `documents` déjà créés en base mais
   jamais utilisés. Upload, téléchargement (URL signée), suppression.
9. **Emploi du temps éditable** : nouvelle page `/dashboard/emploi-temps`
   (création/suppression de créneaux par classe, réservé admin/direction
   comme le prévoit la RLS `schedules_write_admin`). Nouvelle ressource de
   permission `emploi_temps` ajoutée à la matrice de rôles.
10. **Journal d'audit consultable** : nouvelle page `/dashboard/audit`
    (recherche par utilisateur/action), réutilise `getRecentActivity()`
    qui lisait déjà la table `audit_logs` (alimentée automatiquement par
    trigger) mais n'était affichée que partiellement dans la fiche
    professeur.
11. **Recherche globale du header** : le champ était purement visuel — il
    recherche maintenant en temps réel parmi les étudiants et professeurs
    déjà chargés et ouvre directement la fiche correspondante.

## Pas encore fait

- **Espace/rôle Parent** : reporté — c'est le chantier le plus lourd
  restant (tableau de bord dédié filtré sur les enfants liés, écran de
  liaison parent ↔ étudiant). Mérite un lot à part entière plutôt qu'une
  implémentation précipitée.
- Export CSV/Excel des listes.
- Pagination de la grille professeurs.
- Remplacement des `alert()`/`confirm()` natifs par des modales cohérentes.
- Squelettes de chargement.
