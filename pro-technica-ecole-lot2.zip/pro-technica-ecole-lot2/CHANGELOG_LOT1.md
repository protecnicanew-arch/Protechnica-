# Lot 1 — Correction des 9 routes cassées (2026-09-27)

## Ce qui a été livré

1. **Nouvelle route API serveur** `app/api/admin/create-user/route.ts` (clé service_role,
   réservée admin/direction) pour créer un compte étudiant ou professeur sans
   déconnecter l'administrateur (problème que `supabase.auth.signUp()` côté
   client aurait provoqué).
2. **`/dashboard/etudiants/nouveau`** — formulaire complet de création d'étudiant
   (compte Auth + fiche `students`).
3. **`/dashboard/professeurs/nouveau`** — formulaire complet de création de
   professeur (compte Auth + fiche `teachers` + matières + classes).
4. **`/dashboard/paiements`** — facturation, recherche/filtre par statut,
   encaissement de versements (branché sur `payments.service.ts`, déjà prêt).
5. **`/dashboard/actualites`** — liste + publication d'annonces (branché sur
   `announcements.service.ts`, déjà prêt).
6. **`/dashboard/comptabilite`** — dépenses + bilan recettes/dépenses du mois
   (branché sur `comptabilite.service.ts`, déjà prêt).
7. **`/dashboard/bibliotheque`** — nouveau `lib/services/library.service.ts`
   (n'existait pas) + page de gestion des ressources.
8. **`/dashboard/parametres`** — nouveau `lib/services/settings.service.ts`
   (n'existait pas) + page de configuration (nom école, année active, seuil
   de retard), réservée admin/direction.
9. **`/dashboard/profil`** — consultation du profil, modification du
   téléphone, changement de mot de passe.
10. **`/dashboard/bulletins`** — génération de moyenne/rang par classe et
    période (réutilise `generateReportCard()`, déjà présent) **+ export PDF**
    via `jspdf`/`jspdf-autotable` (jusqu'ici installés mais jamais utilisés).

## Bonus corrigé au passage (audit §5 — Important)

- **Permissions par rôle appliquées à la navigation** : `Sidebar` et
  `MobileNav` filtrent désormais les liens visibles avec `canAny(role, resource)`
  au lieu d'afficher les 13 mêmes liens à tout le monde.

## Pas encore fait (prochains lots, dans l'ordre du rapport d'audit)

- Export PDF/CSV plus large (reçus de paiement, listes étudiants/paiements).
- Upload réel de documents (onglet Documents de la fiche étudiant — toujours
  factice, `storage.service.ts` est prêt mais pas branché à l'UI).
- Emploi du temps éditable (actuellement lecture seule).
- Espace/rôle Parent.
- Journal d'audit (page de consultation).
- Recherche globale du header (actuellement un champ visuel sans logique).
- Pagination de la grille professeurs, remplacement des `alert()`/`confirm()`
  natifs, squelettes de chargement.
